import java.util.Arrays;
import java.util.Scanner;

public class GerandoPermutacoes {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < n; i++) {
            String str = scanner.nextLine();
            char[] chars = str.toCharArray();
            Arrays.sort(chars);

            do {
                System.out.println(new String(chars));
            } while (nextPermutation(chars));

            if (i < n - 1) {
                System.out.println();
            }
        }

        scanner.close();
    }

    private static boolean nextPermutation(char[] chars) {
        int i = chars.length - 1;
        while (i > 0 && chars[i - 1] >= chars[i]) {
            i--;
        }
        if (i <= 0) {
            return false;
        }

        int j = chars.length - 1;
        while (chars[j] <= chars[i - 1]) {
            j--;
        }

        char temp = chars[i - 1];
        chars[i - 1] = chars[j];
        chars[j] = temp;

        j = chars.length - 1;
        while (i < j) {
            temp = chars[i];
            chars[i] = chars[j];
            chars[j] = temp;
            i++;
            j--;
        }

        return true;
    }
}

