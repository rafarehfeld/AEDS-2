import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class HojeTemProvaCris {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            int instance = 1;
            
            while ((line = reader.readLine()) != null) {
                StringTokenizer st = new StringTokenizer(line);
                int n = Integer.parseInt(st.nextToken());
                int k = Integer.parseInt(st.nextToken());

                if (n == 0 && k == 0) break;

                String[] names = new String[n];
                st = new StringTokenizer(reader.readLine());
                for (int i = 0; i < n; i++) {
                    names[i] = st.nextToken();
                }

                for (int i = 0; i < n - 1 && k > 0; i++) {
                    int pos = i;
                    for (int j = i + 1; j < n && j - i <= k; j++) {
                        if (names[j].compareTo(names[pos]) < 0) {
                            pos = j;
                        }
                    }
                    // Bubble the smallest found element to position i
                    for (int j = pos; j > i; j--) {
                        String temp = names[j];
                        names[j] = names[j - 1];
                        names[j - 1] = temp;
                        k--;
                    }
                }

                System.out.printf("Instancia %d%n", instance++);
                for (String name : names) {
                    System.out.print(name + " ");
                }
                System.out.println();
                System.out.println();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
