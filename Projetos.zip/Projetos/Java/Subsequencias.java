import java.util.Scanner;

public class Subsequencias {
    
    public static boolean isSubsequence(String s, String r) {
        int i = 0, j = 0;
        int s_len = s.length(), r_len = r.length();
        
        while (i < s_len && j < r_len) {
            if (s.charAt(i) == r.charAt(j)) {
                j++;
            }
            i++;
        }
        return j == r_len;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int n = sc.nextInt();
        
        for (int i = 0; i < n; i++) {
            String s = sc.next();
            int q = sc.nextInt();
            
            for (int j = 0; j < q; j++) {
                String r = sc.next();
                if (isSubsequence(s, r)) {
                    System.out.println("Yes");
                } else {
                    System.out.println("No");
                }
            }
        }
        
        sc.close();
    }
}
