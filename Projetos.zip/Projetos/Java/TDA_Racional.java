import java.util.Scanner;

public class TDA_Racional {
    
    // Função para calcular o máximo divisor comum
    public static int gcd(int a, int b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    // Função para simplificar a fração
    public static void simplify(int[] fraction) {
        int numerator = fraction[0];
        int denominator = fraction[1];
        int common_divisor = gcd(numerator, denominator);
        fraction[0] = numerator / common_divisor;
        fraction[1] = denominator / common_divisor;
    }

    // Função principal
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();

        while (n-- > 0) {
            int n1 = sc.nextInt();
            sc.next(); // /
            int d1 = sc.nextInt();
            char op = sc.next().charAt(0);
            int n2 = sc.nextInt();
            sc.next(); // /
            int d2 = sc.nextInt();

            int nr = 0, dr = 0;
            switch (op) {
                case '+':
                    nr = n1 * d2 + n2 * d1;
                    dr = d1 * d2;
                    break;
                case '-':
                    nr = n1 * d2 - n2 * d1;
                    dr = d1 * d2;
                    break;
                case '*':
                    nr = n1 * n2;
                    dr = d1 * d2;
                    break;
                case '/':
                    nr = n1 * d2;
                    dr = n2 * d1;
                    break;
            }

            System.out.print(nr + "/" + dr + " = ");
            int[] fraction = {nr, dr};
            simplify(fraction);
            System.out.println(fraction[0] + "/" + fraction[1]);
        }

        sc.close();
    }
}
