import java.util.Scanner;
import java.util.Stack;

public class GiftCard {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {
            int n = scanner.nextInt();
            Stack<Character> st = new Stack<>();
            st.push('F');
            st.push('A');
            st.push('C');
            st.push('E');
            int cont = 0;

            while (n-- > 0) {
                char a = scanner.next().charAt(0);
                char b = scanner.next().charAt(0);
                char c = scanner.next().charAt(0);
                char d = scanner.next().charAt(0);

                if (!st.isEmpty()) {
                    char p = st.pop();
                    char s = st.pop();
                    char t = st.pop();
                    char q = st.pop();

                    if (a == p && b == s && c == t && d == q) {
                        cont++;
                    } else {
                        st.push(q);
                        st.push(t);
                        st.push(s);
                        st.push(p);
                        st.push(a);
                        st.push(b);
                        st.push(c);
                        st.push(d);
                    }
                } else {
                    // Tratamento para pilha vazia (se necessário)
                    cont++;
                }
            }

            System.out.println(cont);
        }
    }
}
