import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class GloudComputing {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            int N = scanner.nextInt();
            int M = scanner.nextInt();

            if (N == 0 && M == 0) {
                break;
            }

            // Lê os servidores
            Map<String, Set<Integer>> appToServers = new HashMap<>();
            for (int i = 0; i < N; i++) {
                int Qi = scanner.nextInt();
                for (int j = 0; j < Qi; j++) {
                    String app = scanner.next();
                    appToServers.computeIfAbsent(app, k -> new HashSet<>()).add(i);
                }
            }

            // Lê os clientes
            int totalConnections = 0;
            for (int i = 0; i < M; i++) {
                int Pj = scanner.nextInt();
                Set<Integer> connectedServers = new HashSet<>();
                for (int j = 0; j < Pj; j++) {
                    String app = scanner.next();
                    if (appToServers.containsKey(app)) {
                        connectedServers.addAll(appToServers.get(app));
                    }
                }
                totalConnections += connectedServers.size();
            }

            System.out.println(totalConnections);
        }

        scanner.close();
    }
}
