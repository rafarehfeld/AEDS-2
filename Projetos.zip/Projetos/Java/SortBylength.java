import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class SortBylength {

    static class StringWithIndex {
        String str;
        int index;

        StringWithIndex(String str, int index) {
            this.str = str;
            this.index = index;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        sc.nextLine(); // Consume newline after integer input

        for (int i = 0; i < N; i++) {
            List<StringWithIndex> strings = new ArrayList<>();
            int index = 0;

            while (sc.hasNext()) {
                String word = sc.next();
                strings.add(new StringWithIndex(word, index++));
                if (sc.hasNextLine()) {
                    sc.nextLine(); // Move to next line
                    break;
                }
            }

            strings.sort(new Comparator<StringWithIndex>() {
                @Override
                public int compare(StringWithIndex o1, StringWithIndex o2) {
                    if (o1.str.length() != o2.str.length()) {
                        return o1.str.length() - o2.str.length();
                    }
                    return o1.index - o2.index;
                }
            });

            for (int j = 0; j < strings.size(); j++) {
                if (j > 0) {
                    System.out.print(" ");
                }
                System.out.print(strings.get(j).str);
            }
            System.out.println();
        }

        sc.close();
    }
}
