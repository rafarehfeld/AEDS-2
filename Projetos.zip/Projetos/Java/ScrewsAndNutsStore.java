import java.util.*;

public class ScrewsAndNutsStore {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextInt()) {
            int N = scanner.nextInt();
            List<int[]> intervals = new ArrayList<>();

            for (int i = 0; i < N; i++) {
                int X = scanner.nextInt();
                int Y = scanner.nextInt();
                intervals.add(new int[]{X, Y});
            }

            int Num = scanner.nextInt();
            List<Integer> positions = new ArrayList<>();
            int currentIndex = 1; // Start at position 1

            for (int[] interval : intervals) {
                for (int j = interval[0]; j <= interval[1]; j++) {
                    if (j == Num) {
                        positions.add(currentIndex);
                    }
                    currentIndex++;
                }
            }

            if (positions.isEmpty()) {
                System.out.println(Num + " not found");
            } else {
                System.out.println(Num + " found from " + positions.get(0) + " to " + positions.get(positions.size() - 1));
            }
        }

        scanner.close();
    }
}
