import java.util.*;

public class Aviao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<String> leste = new LinkedList<>();
        Queue<String> norte = new LinkedList<>();
        Queue<String> sul = new LinkedList<>();
        Queue<String> oeste = new LinkedList<>();

        int ponto = scanner.nextInt();
        scanner.nextLine(); 

        while (true) {
            String entrada = scanner.nextLine();
            if (entrada.equals("0")) {
                break;
            } else if (entrada.charAt(0) == '-') {
                ponto = Integer.parseInt(entrada.split(" ")[0]); // Extract the integer part
            } else {
                switch (ponto) {
                    case -1:
                        oeste.offer(entrada);
                        break;
                    case -2:
                        sul.offer(entrada);
                        break;
                    case -3:
                        norte.offer(entrada);
                        break;
                    case -4:
                        leste.offer(entrada);
                        break;
                }
            }
        }

        while (!oeste.isEmpty() || !norte.isEmpty() || !sul.isEmpty() || !leste.isEmpty()) {
            if (!oeste.isEmpty()) {
                System.out.print(oeste.poll() + " ");
            }
            if (!norte.isEmpty()) {
                System.out.print(norte.poll() + " ");
            }
            if (!sul.isEmpty()) {
                System.out.print(sul.poll() + " ");
            }
            if (!leste.isEmpty()) {
                System.out.print(leste.poll() + " ");
            }
        }
    }
}