import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Frequencia{
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line;
        boolean first = true;

        while ((line = br.readLine()) != null) {
            int[] freq = new int[128];
            Arrays.fill(freq, 0);

            for (char ch : line.toCharArray()) {
                if (ch >= 32 && ch < 128) {
                    freq[ch]++;
                }
            }

            if (!first) {
                System.out.println();
            }
            first = false;

            printFrequencies(freq);
        }
    }

    private static void printFrequencies(int[] freq) {
        int[][] countChar = new int[128][2];
        int index = 0;

        for (int i = 0; i < 128; i++) {
            if (freq[i] > 0) {
                countChar[index][0] = freq[i];
                countChar[index][1] = i;
                index++;
            }
        }

        Arrays.sort(countChar, 0, index, (a, b) -> {
            if (a[0] == b[0]) {
                return Integer.compare(b[1], a[1]);
            }
            return Integer.compare(a[0], b[0]);
        });

        for (int i = 0; i < index; i++) {
            System.out.println(countChar[i][1] + " " + countChar[i][0]);
        }
    }
}
