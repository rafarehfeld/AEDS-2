import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Paises implements Comparable<Paises>{
	String nome;
	int ouro;
	int prata;
	int bronze;
	
	public Paises(String nome) {
		this.nome = nome;
		this.ouro = 0;
		this.prata = 0;
		this.bronze = 0;
	}

	@Override
	public int compareTo(Paises p) {
		if(this.ouro < p.ouro) {
			return 1;
		}
		if(this.ouro > p.ouro) {
			return -1;
		}
		if(this.ouro == p.ouro) {
			if(this.prata < p.prata) {
				return 1;
			}
			if(this.prata > p.prata) {
				return -1;
			}
			if(this.prata == p.prata) {
				if(this.bronze < p.bronze) {
					return 1;
				}
				if(this.bronze > p.bronze) {
					return -1;
				}
				if(this.bronze == p.bronze) {
					return this.nome.compareTo(p.nome);
				}
			}
		}
		return 0;	
	}
}

public class OlimpiadasdeNatal {
	public static void main(String args[]) {
		String descrisao;
		Scanner sc = new Scanner (System.in);
		ArrayList<Paises> pais = new ArrayList<>();
		
		while(sc.hasNext()) {
			descrisao=sc.nextLine();
			if (descrisao.trim().isEmpty()) {
                break; // Handle empty lines as a signal to stop reading
            }
			String ouro, prata, bronze;
			ouro = sc.nextLine();
			prata = sc.nextLine();
			bronze = sc.nextLine();
			int a = verificapais(ouro,pais);
			int b = verificapais(prata,pais);
			int c = verificapais(bronze,pais);
			pais.get(a).ouro++;
			pais.get(b).prata++;
			pais.get(c).bronze++;
		}
		
		Collections.sort(pais);
		
		System.out.println("Quadro de Medalhas");
		for(int i=0; i<pais.size(); i++) {
			System.out.println( pais.get(i).nome+" "+pais.get(i).ouro+" "+pais.get(i).prata+" "+pais.get(i).bronze);
		}
	}
	
	public static int verificapais(String nome, ArrayList<Paises> pais) {
		int tam = pais.size();
		for(int i=0; i < tam; i++) {
			if(nome.equals(pais.get(i).nome)) {
				return i;
			}
		}
		Paises novo = new Paises(nome);
		pais.add(novo);
		return tam;
	}
}
