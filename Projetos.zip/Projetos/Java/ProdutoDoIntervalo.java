import java.util.Scanner;

public class ProdutoDoIntervalo {
    
    static int[] arr;
    static int[] segTree;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            int N = scanner.nextInt();
            int K = scanner.nextInt();
            
            arr = new int[N];
            segTree = new int[4 * N];
            
            for (int i = 0; i < N; i++) {
                arr[i] = scanner.nextInt();
            }
            
            build(1, 0, N - 1);
            
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < K; i++) {
                char command = scanner.next().charAt(0);
                int I = scanner.nextInt();
                int V = scanner.nextInt();
                
                if (command == 'C') {
                    update(1, 0, N - 1, I - 1, V);
                } else if (command == 'P') {
                    int product = query(1, 0, N - 1, I - 1, V - 1);
                    if (product > 0) {
                        result.append('+');
                    } else if (product < 0) {
                        result.append('-');
                    } else {
                        result.append('0');
                    }
                }
            }
            System.out.println(result.toString());
        }
        scanner.close();
    }

    static void build(int node, int start, int end) {
        if (start == end) {
            if (arr[start] > 0) {
                segTree[node] = 1;
            } else if (arr[start] < 0) {
                segTree[node] = -1;
            } else {
                segTree[node] = 0;
            }
        } else {
            int mid = (start + end) / 2;
            build(2 * node, start, mid);
            build(2 * node + 1, mid + 1, end);
            segTree[node] = segTree[2 * node] * segTree[2 * node + 1];
        }
    }

    static void update(int node, int start, int end, int idx, int val) {
        if (start == end) {
            if (val > 0) {
                segTree[node] = 1;
            } else if (val < 0) {
                segTree[node] = -1;
            } else {
                segTree[node] = 0;
            }
        } else {
            int mid = (start + end) / 2;
            if (start <= idx && idx <= mid) {
                update(2 * node, start, mid, idx, val);
            } else {
                update(2 * node + 1, mid + 1, end, idx, val);
            }
            segTree[node] = segTree[2 * node] * segTree[2 * node + 1];
        }
    }

    static int query(int node, int start, int end, int L, int R) {
        if (R < start || end < L) {
            return 1;
        }
        if (L <= start && end <= R) {
            return segTree[node];
        }
        int mid = (start + end) / 2;
        int leftQuery = query(2 * node, start, mid, L, R);
        int rightQuery = query(2 * node + 1, mid + 1, end, L, R);
        return leftQuery * rightQuery;
    }
}
