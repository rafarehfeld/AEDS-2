import java.util.Scanner;

public class TrainSwapping {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int N = scanner.nextInt(); // Number of test cases
        for (int i = 0; i < N; i++) {
            int L = scanner.nextInt(); // Length of the train
            int[] train = new int[L];
            for (int j = 0; j < L; j++) {
                train[j] = scanner.nextInt();
            }
            int swaps = bubbleSortAndCountSwaps(train);
            System.out.println("Optimal train swapping takes " + swaps + " swaps.");
        }
        scanner.close();
    }

    private static int bubbleSortAndCountSwaps(int[] arr) {
        int n = arr.length;
        int swapCount = 0;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap arr[j] and arr[j + 1]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapCount++;
                    swapped = true;
                }
            }
            // If no two elements were swapped in the inner loop, then the array is sorted
            if (!swapped) {
                break;
            }
        }
        return swapCount;
    }
}

