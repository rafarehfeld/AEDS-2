import java.util.Scanner;

public class IntervalProduct {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {
            int N = scanner.nextInt();
            int K = scanner.nextInt();

            int[] array = new int[N];
            for (int i = 0; i < N; i++) {
                array[i] = scanner.nextInt();
            }

            SegmentTree segmentTree = new SegmentTree(array);

            StringBuilder result = new StringBuilder();
            for (int i = 0; i < K; i++) {
                String command = scanner.next();
                int I = scanner.nextInt();
                int J = scanner.nextInt();

                if (command.equals("C")) {
                    segmentTree.update(I - 1, J); // Convert to 0-based index
                } else if (command.equals("P")) {
                    int product = segmentTree.product(I - 1, J - 1); // Convert to 0-based index
                    if (product > 0) {
                        result.append('+');
                    } else if (product < 0) {
                        result.append('-');
                    } else {
                        result.append('0');
                    }
                }
            }

            System.out.println(result.toString());
        }

        scanner.close();
    }
}

class SegmentTree {
    private int[] tree;
    private int[] array;
    private int n;

    public SegmentTree(int[] array) {
        this.n = array.length;
        this.array = array;
        this.tree = new int[4 * n];
        build(0, 0, n - 1);
    }

    private void build(int node, int start, int end) {
        if (start == end) {
            tree[node] = getSign(array[start]);
        } else {
            int mid = (start + end) / 2;
            int leftChild = 2 * node + 1;
            int rightChild = 2 * node + 2;

            build(leftChild, start, mid);
            build(rightChild, mid + 1, end);

            tree[node] = tree[leftChild] * tree[rightChild];
        }
    }

    private int getSign(int value) {
        if (value > 0) return 1;
        if (value < 0) return -1;
        return 0;
    }

    public void update(int idx, int value) {
        update(0, 0, n - 1, idx, value);
    }

    private void update(int node, int start, int end, int idx, int value) {
        if (start == end) {
            array[idx] = value;
            tree[node] = getSign(value);
        } else {
            int mid = (start + end) / 2;
            int leftChild = 2 * node + 1;
            int rightChild = 2 * node + 2;

            if (start <= idx && idx <= mid) {
                update(leftChild, start, mid, idx, value);
            } else {
                update(rightChild, mid + 1, end, idx, value);
            }

            tree[node] = tree[leftChild] * tree[rightChild];
        }
    }

    public int product(int l, int r) {
        return product(0, 0, n - 1, l, r);
    }

    private int product(int node, int start, int end, int l, int r) {
        if (r < start || end < l) {
            return 1;
        }

        if (l <= start && end <= r) {
            return tree[node];
        }

        int mid = (start + end) / 2;
        int leftChild = 2 * node + 1;
        int rightChild = 2 * node + 2;

        int leftProduct = product(leftChild, start, mid, l, r);
        int rightProduct = product(rightChild, mid + 1, end, l, r);

        return leftProduct * rightProduct;
    }
}

