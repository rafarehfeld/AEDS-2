import java.util.Scanner;

public class Muitos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt(); // number of years
        scanner.nextLine(); // move to the next line
        
        int[] wrong_counts = new int[4]; // array to count the wrong guesses
        
        for (int year = 0; year < N; year++) {
            // Skip "Palpites"
            scanner.nextLine();
            
            // Read guesses
            String[] guesses = new String[4];
            for (int i = 0; i < 4; i++) {
                guesses[i] = scanner.nextLine();
            }
            
            // Skip "Vencedores"
            scanner.nextLine();
            
            // Read winners
            String[] winners = new String[4];
            for (int i = 0; i < 4; i++) {
                winners[i] = scanner.nextLine();
            }
            
            // Compare guesses with winners
            for (int i = 0; i < 4; i++) {
                if (!guesses[i].equals(winners[i])) {
                    wrong_counts[i]++;
                }
            }
        }
        
        // Output categories with the most wrong guesses
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            if (wrong_counts[i] == getMaxWrongCount(wrong_counts)) {
                result.append((i + 1)).append(" ");
            }
        }
        
        System.out.println(result.toString().trim());
        
        scanner.close();
    }
    
    // Helper function to find the maximum value in the wrong_counts array
    private static int getMaxWrongCount(int[] counts) {
        int max = Integer.MIN_VALUE;
        for (int count : counts) {
            if (count > max) {
                max = count;
            }
        }
        return max;
    }
}
