import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class OFantasticoJaspion {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int T = scanner.nextInt();
        scanner.nextLine(); // Consome a nova linha após o número de casos de teste

        while (T-- > 0) {
            int M = scanner.nextInt();
            int N = scanner.nextInt();
            scanner.nextLine(); // Consome a nova linha após M e N

            Map<String, String> dicionario = new HashMap<>();
            for (int i = 0; i < M; i++) {
                String jap = scanner.nextLine().trim();
                String por = scanner.nextLine().trim();
                dicionario.put(jap, por);
            }

            for (int i = 0; i < N; i++) {
                String linha = scanner.nextLine().trim();
                String[] palavras = linha.split(" ");
                StringBuilder traducao = new StringBuilder();

                for (String palavra : palavras) {
                    if (dicionario.containsKey(palavra)) {
                        traducao.append(dicionario.get(palavra));
                    } else {
                        traducao.append(palavra);
                    }
                    traducao.append(" ");
                }
                // Remove o espaço extra no final
                if (traducao.length() > 0) {
                    traducao.setLength(traducao.length() - 1);
                }

                System.out.println(traducao.toString());
            }

            if (T > 0) {
                System.out.println();
            }
        }
        scanner.close();
    }
}
