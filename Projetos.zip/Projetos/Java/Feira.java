import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Feira {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();

        for (int i = 0; i < N; i++) {
            int M = scanner.nextInt();
            Map<String, Double> productPrices = new HashMap<>();

            for (int j = 0; j < M; j++) {
                String productName = scanner.next();
                double price = scanner.nextDouble();
                productPrices.put(productName, price);
            }

            int P = scanner.nextInt();
            double totalCost = 0.0;

            for (int j = 0; j < P; j++) {
                String productName = scanner.next();
                int quantity = scanner.nextInt();
                if (productPrices.containsKey(productName)) {
                    totalCost += productPrices.get(productName) * quantity;
                }
            }

            System.out.printf("R$ %.2f%n", totalCost);
        }

        scanner.close();
    }
}
