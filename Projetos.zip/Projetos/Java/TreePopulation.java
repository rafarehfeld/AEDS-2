import java.util.*;

public class TreePopulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int testCases = Integer.parseInt(scanner.nextLine().trim());
        scanner.nextLine(); // consume the blank line after the number of test cases

        for (int t = 0; t < testCases; t++) {
            Map<String, Integer> treeCount = new HashMap<>();
            int totalTrees = 0;

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if (line.isEmpty()) break; // end of current test case

                treeCount.put(line, treeCount.getOrDefault(line, 0) + 1);
                totalTrees++;
            }

            List<String> speciesList = new ArrayList<>(treeCount.keySet());
            Collections.sort(speciesList);

            for (String species : speciesList) {
                int count = treeCount.get(species);
                double percentage = (count * 100.0) / totalTrees;
                System.out.printf("%s %.4f%n", species, percentage);
            }

            if (t < testCases - 1) {
                System.out.println();
            }
        }

        scanner.close();
    }
}
