import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Child {
    String name;
    int token;

    Child(String name, int token) {
        this.name = name;
        this.token = token;
    }
}

public class Acampamento {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        while (true) {
            int N = sc.nextInt();
            if (N == 0) break;

            List<Child> children = new ArrayList<>();
            for (int i = 0; i < N; i++) {
                String name = sc.next();
                int token = sc.nextInt();
                children.add(new Child(name, token));
            }

            int index = 0;
            while (children.size() > 1) {
                Child currentChild = children.get(index);
                int steps = currentChild.token;
                int direction = (steps % 2 == 0) ? 1 : -1;  // 1 para horário, -1 para anti-horário

                children.remove(index);
                if (direction == 1) {
                    index = (index + steps - 1) % children.size();
                } else {
                    index = (index - steps) % children.size();
                    if (index < 0) {
                        index += children.size();
                    }
                }
            }

            System.out.println("Vencedor(a): " + children.get(0).name);
        }

        sc.close();
    }
}
