import java.util.*;

public class PrettyNetworks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            String line = scanner.nextLine().trim();
            if (line.equals("0")) {
                break;
            }

            String[] parts = line.split(" ");
            int N = Integer.parseInt(parts[0]);
            if (N == 0) {
                break;
            }

            int[] target = new int[N];
            for (int i = 0; i < N; i++) {
                target[i] = Integer.parseInt(parts[i + 1]) - 1;
            }

            int[] current = new int[N];
            for (int i = 0; i < N; i++) {
                current[i] = i;
            }

            List<Integer> strokes = new ArrayList<>();

            boolean possible = true;
            for (int k = 0; k < 4 * N * N && possible; k++) {
                possible = false;
                for (int i = 0; i < N - 1; i++) {
                    if (current[i] != target[i] && current[i + 1] != target[i + 1]) {
                        strokes.add(i + 1);
                        int temp = current[i];
                        current[i] = current[i + 1];
                        current[i + 1] = temp;
                        possible = true;
                    }
                }

                if (Arrays.equals(current, target)) {
                    possible = true;
                    break;
                }
            }

            if (Arrays.equals(current, target)) {
                System.out.print(strokes.size());
                for (int stroke : strokes) {
                    System.out.print(" " + stroke);
                }
                System.out.println();
            } else {
                System.out.println("No solution");
            }
        }
    }
}

