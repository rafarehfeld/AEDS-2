import java.util.ArrayList;
import java.util.Scanner;

class Node {
    int key;
    Node next;

    Node(int key) {
        this.key = key;
        this.next = null;
    }
}

public class HashTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();

        for (int i = 0; i < N; i++) {
            int M = scanner.nextInt();
            int C = scanner.nextInt();

            ArrayList<Node>[] hashTable = new ArrayList[M];
            for (int j = 0; j < M; j++) {
                hashTable[j] = new ArrayList<>();
            }

            for (int j = 0; j < C; j++) {
                int key = scanner.nextInt();
                insert(hashTable, key, M);
            }

            printHashTable(hashTable, M);
            if (i < N - 1) {
                System.out.println();
            }
        }
        scanner.close();
    }

    static void insert(ArrayList<Node>[] hashTable, int key, int M) {
        int index = key % M;
        Node newNode = new Node(key);
        if (hashTable[index].isEmpty()) {
            hashTable[index].add(newNode);
        } else {
            Node temp = hashTable[index].get(0);
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    static void printHashTable(ArrayList<Node>[] hashTable, int M) {
        for (int i = 0; i < M; i++) {
            System.out.print(i + " ->");
            if (!hashTable[i].isEmpty()) {
                Node temp = hashTable[i].get(0);
                while (temp != null) {
                    System.out.print(" " + temp.key + " ->");
                    temp = temp.next;
                }
            }
            System.out.println(" \\");
        }
    }
}
