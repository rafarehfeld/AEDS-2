import java.util.Scanner;

public class OrdPedro {

    static class Creature {
        String name;
        int powerLevel;
        int godsKilled;
        int timesDied;

        Creature(String name, int powerLevel, int godsKilled, int timesDied) {
            this.name = name;
            this.powerLevel = powerLevel;
            this.godsKilled = godsKilled;
            this.timesDied = timesDied;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Creature godofor = null;
        for (int i = 0; i < N; i++) {
            String name = scanner.next();
            int powerLevel = scanner.nextInt();
            int godsKilled = scanner.nextInt();
            int timesDied = scanner.nextInt();
            Creature candidate = new Creature(name, powerLevel, godsKilled, timesDied);
            if (godofor == null || isBetterCandidate(candidate, godofor)) {
                godofor = candidate;
            }
        }
        System.out.println(godofor.name);
        scanner.close();
    }

    private static boolean isBetterCandidate(Creature candidate, Creature currentGodofor) {
        if (candidate.powerLevel != currentGodofor.powerLevel) {
            return candidate.powerLevel > currentGodofor.powerLevel;
        }
        if (candidate.godsKilled != currentGodofor.godsKilled) {
            return candidate.godsKilled > currentGodofor.godsKilled;
        }
        if (candidate.timesDied != currentGodofor.timesDied) {
            return candidate.timesDied < currentGodofor.timesDied;
        }
        return candidate.name.compareTo(currentGodofor.name) < 0;
    }
}