import java.util.*;

public class JogoEsperto {

    public static int minOperations(int N, int M) {
        if (N == M) {
            return 0;
        }

        Queue<int[]> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();
        
        queue.add(new int[]{N, 0});
        visited.add(N);
        
        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int value = current[0];
            int ops = current[1];
            
            // Lista de possíveis operações
            int[] nextValues = {
                value * 2,
                value * 3,
                value % 2 == 0 ? value / 2 : value,
                value % 3 == 0 ? value / 3 : value,
                value + 7,
                value - 7
            };
            
            for (int nextValue : nextValues) {
                if (nextValue == M) {
                    return ops + 1;
                }
                if (nextValue >= 0 && nextValue <= 10000 && !visited.contains(nextValue)) {
                    visited.add(nextValue);
                    queue.add(new int[]{nextValue, ops + 1});
                }
            }
        }
        
        // Caso em que não encontramos uma solução (não deve ocorrer com os limites dados)
        return -1;
    }

    public static void main(String[] args) {
        // Exemplos de teste
        System.out.println(minOperations(10, 15)); // Saída esperada: 2
        System.out.println(minOperations(45, 15)); // Saída esperada: 1
        System.out.println(minOperations(84, 63)); // Saída esperada: 3
    }
}

