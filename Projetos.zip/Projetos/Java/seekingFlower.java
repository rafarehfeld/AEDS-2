import java.util.Scanner;

public class seekingFlower {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int N = scanner.nextInt(); 
        int M = scanner.nextInt();
        
        int[] D = new int[30];
        for (int i = 0; i < 30; i++) {
            D[i] = scanner.nextInt();
        }     
        scanner.close();
        int baixo= 0;
        int alto = 100000;
        
        while (baixo< alto) {
            int meio= baixo+ (alto - baixo) / 2;
            
            if (diasParaBaterAMeta(N, M, D, meio)) {
                alto = meio;
            } else {
                baixo= meio+ 1;
            }
        }
        
        System.out.println(baixo);
    }
    
    private static boolean diasParaBaterAMeta(int seguidoresAtuais, int seguidoresMeta, int[] D, int dias) {
        long totalSeguidores = seguidoresAtuais;
        
        for (int i = Math.max(0, 30 - dias); i < 30; i++) {
            totalSeguidores += D[i];
            if (totalSeguidores >= seguidoresMeta) {
                return true;
            }
        }
        
        return false;
    }
}
