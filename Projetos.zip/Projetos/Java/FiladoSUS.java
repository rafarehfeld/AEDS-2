import java.util.Scanner;

class Paciente{
	int hora;
	int minuto;
	int critico;
	
	public Paciente(int h, int m, int c) {
		this.hora=h;
		this.minuto=m;
		this.critico=c;
	}
}

class Atendimento{
	int hora;
	int minuto;
	public  Atendimento(int h, int m){
		this.hora=h;
		this.minuto=m;
	}
	public void Att(int h, int m){
		if(m<=30) {
			this.minuto=30;
		}else {
			this.hora++;
			this.minuto=0;
		}
	}
	public void AttMax(int h, int m){
		if(this.minuto<30) {
			this.minuto=30;
		}else {
			this.hora++;
			this.minuto=0;
		}
	}
}


public class FiladoSUS {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int x=0;

		while(sc.hasNextInt()) {
			int naoatendido = 0;
			x=sc.nextInt();
			Paciente[] vet = new Paciente[x];
			for(int i=0;i<x;i++) {
				int h,m,c;
				h=sc.nextInt();
				m=sc.nextInt();
				c=sc.nextInt();
				vet[i]=new Paciente(h,m,c);
			}
			Atendimento medico = new Atendimento(vet[0].hora,vet[0].minuto);
			for(int i=0;i<x;i++) {
				if(i== 0) {
					medico.Att(vet[i].hora,vet[i].minuto);
				}else if(medico.hora < vet[i].hora){
					medico.Att(vet[i].hora, vet[i].minuto);
				}else {
					if(medico.hora == vet[i].hora) {
						medico.AttMax(vet[i].hora, vet[i].minuto);
					}else {
						vet[i].minuto+=vet[i].critico;
						if(vet[i].minuto>=60) {
							vet[i].minuto-=60;
							vet[i].hora++;
						}
						if(medico.hora==vet[i].critico && medico.minuto <= vet[i].critico) {
							medico.AttMax(vet[i].hora, vet[i].minuto);
						}else {
							naoatendido++;
						}
					}	
				}
			}
			System.out.println(naoatendido);
		}
	}
}
