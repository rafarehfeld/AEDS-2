import java.util.*;

public class cafeteriaqueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNext()) {
            int N = scanner.nextInt();
            int K = scanner.nextInt();
            int[] positions = new int[N];
            positions[0] = 0;
            for (int i = 1; i < N; i++) {
                positions[i] = scanner.nextInt();
            }

            // Matriz de DP para armazenar os resultados
            int[][] dp = new int[N][K + 1];

            // Preenche a matriz dp com valores máximos
            for (int[] row : dp) {
                Arrays.fill(row, Integer.MAX_VALUE);
            }

            // Inicializa a primeira coluna de dp (um grupo)
            for (int i = 0; i < N; i++) {
                dp[i][1] = positions[i] - positions[0];
            }

            // Calcula os valores de DP
            for (int k = 2; k <= K; k++) {
                for (int i = k - 1; i < N; i++) {
                    for (int j = k - 2; j < i; j++) {
                        dp[i][k] = Math.min(dp[i][k], dp[j][k - 1] + (positions[i] - positions[j + 1]));
                    }
                }
            }

            // Resultado é o valor mínimo da última linha e da última coluna
            int result = dp[N - 1][K];

            System.out.println(result);
        }

        scanner.close();
    }
}
