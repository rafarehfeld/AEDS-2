import java.util.*;
import java.util.regex.*;
import java.io.*;

public class Lexsim {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (scanner.hasNextLine()) {
            String expression = scanner.nextLine().trim();
            if (expression.isEmpty()) {
                continue;
            }
            processExpression(expression);
        }
    }

    private static void processExpression(String expression) {
        if (!isValidCharacters(expression)) {
            System.out.println("Lexical Error!");
            return;
        }
        
        try {
            String postfix = infixToPostfix(expression);
            System.out.println(postfix);
        } catch (Exception e) {
            System.out.println("Syntax Error!");
        }
    }

    private static boolean isValidCharacters(String expression) {
        String validCharacters = "^[a-zA-Z0-9\\^*/+\\-><=#,.|()]+$";
        Pattern pattern = Pattern.compile(validCharacters);
        Matcher matcher = pattern.matcher(expression);
        return matcher.matches();
    }

    private static String infixToPostfix(String expression) throws Exception {
        Stack<Character> stack = new Stack<>();
        StringBuilder postfix = new StringBuilder();
        boolean lastWasOperand = false;

        for (char c : expression.toCharArray()) {
            if (Character.isLetterOrDigit(c)) {
                postfix.append(c);
                lastWasOperand = true;
            } else if (c == '(') {
                stack.push(c);
                lastWasOperand = false;
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix.append(stack.pop());
                }
                if (stack.isEmpty()) {
                    throw new Exception("Mismatched parentheses");
                }
                stack.pop();
                lastWasOperand = true;
            } else if (isOperator(c)) {
                if (!lastWasOperand) {
                    throw new Exception("Invalid operator placement");
                }
                while (!stack.isEmpty() && precedence(c) <= precedence(stack.peek())) {
                    postfix.append(stack.pop());
                }
                stack.push(c);
                lastWasOperand = false;
            } else {
                throw new Exception("Invalid character");
            }
        }

        while (!stack.isEmpty()) {
            char top = stack.pop();
            if (top == '(' || top == ')') {
                throw new Exception("Mismatched parentheses");
            }
            postfix.append(top);
        }

        return postfix.toString();
    }

    private static boolean isOperator(char c) {
        return "^*/+-><=#.|".indexOf(c) != -1;
    }

    private static int precedence(char operator) {
        switch (operator) {
            case '^': return 6;
            case '*': case '/': return 5;
            case '+': case '-': return 4;
            case '>': case '<': case '=': case '#': return 3;
            case '.': return 2; // AND
            case '|': return 1; // OR
            default: return -1;
        }
    }
}

