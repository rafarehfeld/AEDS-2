import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class Tshirt {
    String name;
    String color;
    char size;

    Tshirt(String name, String color, char size) {
        this.name = name;
        this.color = color;
        this.size = size;
    }
}

public class Camisetas{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean first = true;

        while (true) {
            int N = sc.nextInt();
            sc.nextLine();  // Consumir o resto da linha
            if (N == 0) break;

            ArrayList<Tshirt> tshirts = new ArrayList<>();

            for (int i = 0; i < N; i++) {
                String name = sc.nextLine();
                String[] details = sc.nextLine().split(" ");
                String color = details[0];
                char size = details[1].charAt(0);
                tshirts.add(new Tshirt(name, color, size));
            }

            Collections.sort(tshirts, new Comparator<Tshirt>() {
                @Override
                public int compare(Tshirt t1, Tshirt t2) {
                    int colorComparison = t1.color.compareTo(t2.color);
                    if (colorComparison != 0) {
                        return colorComparison;
                    }

                    if (t1.size != t2.size) {
                        return t2.size - t1.size;
                    }

                    return t1.name.compareTo(t2.name);
                }
            });

            if (!first) {
                System.out.println();
            }
            first = false;

            for (Tshirt tshirt : tshirts) {
                System.out.println(tshirt.color + " " + tshirt.size + " " + tshirt.name);
            }
        }

        sc.close();
    }
}
