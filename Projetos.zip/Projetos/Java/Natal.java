import java.util.HashMap;
import java.util.Scanner;

public class Natal {
    public static void main(String[] args) {
        // Criando o banco de dados com os países e suas respectivas frases de Natal
        HashMap<String, String> database = new HashMap<>();
        database.put("brasil", "Feliz Natal!");
        database.put("alemanha", "Frohliche Weihnachten!");
        database.put("austria", "Frohe Weihnacht!");
        database.put("coreia", "Chuk Sung Tan!");
        database.put("espanha", "Feliz Navidad!");
        database.put("grecia", "Kala Christougena!");
        database.put("estados-unidos", "Merry Christmas!");
        database.put("inglaterra", "Merry Christmas!");
        database.put("australia", "Merry Christmas!");
        database.put("portugal", "Feliz Natal!");
        database.put("suecia", "God Jul!");
        database.put("turquia", "Mutlu Noeller");
        database.put("argentina", "Feliz Navidad!");
        database.put("chile", "Feliz Navidad!");
        database.put("mexico", "Feliz Navidad!");
        database.put("antardida", "Merry Christmas!");
        database.put("canada", "Merry Christmas!");
        database.put("irlanda", "Nollaig Shona Dhuit!");
        database.put("belgica", "Zalig Kerstfeest!");
        database.put("italia", "Buon Natale!");
        database.put("libia", "Buon Natale!");
        database.put("siria", "Milad Mubarak!");
        database.put("marrocos", "Milad Mubarak!");
        database.put("japao", "Merii Kurisumasu!");

        // Criando um scanner para receber os nomes dos países
        Scanner scanner = new Scanner(System.in);

        // Iterando sobre os nomes dos países fornecidos
        while (scanner.hasNextLine()) {
            String country = scanner.nextLine().trim().toLowerCase(); // Convertendo para minúsculas e removendo espaços extras

            // Verificando se o país está no banco de dados
            if (database.containsKey(country)) {
                System.out.println(database.get(country)); // Exibindo a frase de Natal correspondente
            } else {
                System.out.println("--- NOT FOUND ---"); // Exibindo mensagem de não encontrado
            }
        }
    }
}
