import java.util.*;

/**
 * throw
 */
public class JogarCartas {

    

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            int n = scanner.nextInt();
            if (n == 0) break;
            
            simulateCardGame(n);
        }
    }
    
    private static void simulateCardGame(int n) {
        Queue<Integer> deck = new LinkedList<>();
        List<Integer> discarded = new ArrayList<>();
        
        // Initialize the deck from 1 to n
        for (int i = 1; i <= n; i++) {
            deck.add(i);
        }
        
        while (deck.size() >= 2) {
            // Step 1: Discard the top card
            int discardedCard = deck.poll();
            discarded.add(discardedCard);
            
            // Step 2: Move the new top card to the bottom
            int newTopCard = deck.poll();
            deck.add(newTopCard);
        }
        
        // Last remaining card
        int remainingCard = deck.poll();
        
        // Output
        printOutput(discarded, remainingCard);
    }
    
    private static void printOutput(List<Integer> discarded, int remainingCard) {
        StringBuilder discardedCardsOutput = new StringBuilder("Discarded cards: ");
        for (int i = 0; i < discarded.size(); i++) {
            discardedCardsOutput.append(discarded.get(i));
            if (i < discarded.size() - 1) {
                discardedCardsOutput.append(", ");
            }
        }
        System.out.println(discardedCardsOutput);
        System.out.println("Remaining card: " + remainingCard);
    }
}
