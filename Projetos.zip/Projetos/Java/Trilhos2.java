import java.util.Scanner;
import java.util.Stack;

public class Trilhos2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            int n = scanner.nextInt();
            if (n == 0) break;
            scanner.nextLine(); // consume the newline character

            String input = scanner.nextLine().replaceAll(" ", "");
            String output = scanner.nextLine().replaceAll(" ", "");

            String result = getOperationsSequence(n, input, output);
            System.out.println(result);
        }

        scanner.close();
    }

    private static String getOperationsSequence(int n, String input, String output) {
        Stack<Character> station = new Stack<>();
        StringBuilder operations = new StringBuilder();

        int inputIndex = 0;
        int outputIndex = 0;

        while (inputIndex < n || outputIndex < n) {
            if (!station.isEmpty() && station.peek() == output.charAt(outputIndex)) {
                station.pop();
                operations.append('R');
                outputIndex++;
            } else if (inputIndex < n) {
                station.push(input.charAt(inputIndex));
                operations.append('I');
                inputIndex++;
            } else {
                return "Impossible";
            }
        }

        return operations.toString();
    }
}
