import java.util.Scanner;

public class TextCompressor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int N = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        for (int i = 0; i < N; i++) {
            String input = scanner.nextLine();
            System.out.println(compress(input));
        }

        scanner.close();
    }

    private static String compress(String input) {
        StringBuilder output = new StringBuilder();
        int length = input.length();
        int count;

        for (int i = 0; i < length; i++) {
            char currentChar = input.charAt(i);

            if (currentChar == ' ') {
                count = 0;
                while (i < length && input.charAt(i) == ' ') {
                    count++;
                    i++;
                }
                i--; // Adjust for the extra increment in the inner loop

                if (count > 2) {
                    while (count > 255) {
                        output.append("$").append((char) 255);
                        count -= 255;
                    }
                    output.append("$").append((char) count);
                } else {
                    for (int j = 0; j < count; j++) {
                        output.append(' ');
                    }
                }
            } else if (currentChar == '0') {
                count = 0;
                while (i < length && input.charAt(i) == '0') {
                    count++;
                    i++;
                }
                i--; // Adjust for the extra increment in the inner loop

                if (count > 2) {
                    while (count > 255) {
                        output.append("#").append((char) 255);
                        count -= 255;
                    }
                    output.append("#").append((char) count);
                } else {
                    for (int j = 0; j < count; j++) {
                        output.append('0');
                    }
                }
            } else {
                output.append(currentChar);
            }
        }

        return output.toString();
    }
}

