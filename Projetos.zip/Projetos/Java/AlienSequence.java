import java.util.*;

public class AlienSequence {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> sequence = new ArrayList<>();
        Queue<String> queue = new LinkedList<>();
        
        // Initialize known elements
        sequence.add("B");
        sequence.add("BA");
        sequence.add("CB");
        sequence.add("BAA");
        sequence.add("BCB");
        sequence.add("CBA");
        sequence.add("DAB");
        sequence.add("BAAA");
        
        // Enqueue known elements
        for (String s : sequence) {
            queue.add(s);
        }
        
        // Precompute the sequence up to the maximum N needed
        while (sequence.size() <= 100000) {
            String current = queue.poll();
            char lastChar = current.charAt(current.length() - 1);
            
            // Generate new elements based on current element
            for (char c = 'A'; c <= lastChar; c++) {
                queue.add(current + c);
                if (sequence.size() <= 100000) {
                    sequence.add(current + c);
                }
            }
        }
        
        while (scanner.hasNext()) {
            int N = scanner.nextInt();
            if (N == 0) break;
            System.out.println(sequence.get(N - 1));
        }
        
        scanner.close();
    }
}
