import java.util.Scanner;

class FilaDeDesempregado {
    int id;
    FilaDeDesempregado prev;
    FilaDeDesempregado next;

    FilaDeDesempregado(int id) {
        this.id = id;
    }
}

public class FilaDeDesempregados {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            int n = scanner.nextInt();
            int k = scanner.nextInt();
            int m = scanner.nextInt();

            if (n == 0 && k == 0 && m == 0) {
                break;
            }

            FilaDeDesempregado list = fill(n);
            FilaDeDesempregado K = list;
            FilaDeDesempregado M = list.prev;

            while (count(list) > 2) {
                K = traverse(K, k, 0);
                M = traverse(M, m, 1);

                FilaDeDesempregado auxK = (K.next == M) ? M.next : K.next;
                FilaDeDesempregado auxM = (M.prev == K) ? K.prev : M.prev;

                if (K == M) {
                    System.out.printf("%3d,", M.id);
                    list = delete(list, K);
                } else {
                    System.out.printf("%3d%3d,", K.id, M.id);
                    list = delete(list, M);
                    list = delete(list, K);
                }

                K = auxK;
                M = auxM;
            }

            if (count(list) == 2) {
                K = traverse(K, k, 0);
                M = traverse(M, m, 1);

                if (K == M) {
                    System.out.printf("%3d,%3d\n", K.id, K.next.id);
                } else {
                    System.out.printf("%3d%3d\n", K.id, K.next.id);
                }
            } else {
                System.out.printf("%3d\n", list.id);
            }
        }

        scanner.close();
    }

    static FilaDeDesempregado fill(int size) {
        FilaDeDesempregado node, nodePrev = null, start = null;

        for (int i = 1; i <= size; ++i) {
            node = new FilaDeDesempregado(i);

            if (start == null) {
                start = node;
            } else {
                nodePrev.next = node;
                node.prev = nodePrev;
            }

            nodePrev = node;
        }

        start.prev = nodePrev;
        nodePrev.next = start;

        return start;
    }

    static FilaDeDesempregado delete(FilaDeDesempregado list, FilaDeDesempregado reg) {
        FilaDeDesempregado nodePrev = reg.prev;
        FilaDeDesempregado nodeNext = reg.next;

        if (reg == list) {
            list = list.next;
            nodePrev.next = list;
            list.prev = nodePrev;
        } else {
            nodePrev.next = nodeNext;
            nodeNext.prev = nodePrev;
        }

        return list;
    }

    static int count(FilaDeDesempregado list) {
        int i = 1;
        FilaDeDesempregado node = list;
        while (list != node.next) {
            node = node.next;
            i++;
        }
        return i;
    }

    static FilaDeDesempregado traverse(FilaDeDesempregado list, int n, int direction) {
        FilaDeDesempregado node = list;
        if (direction == 0) {
            while (--n > 0) {
                node = node.next;
            }
        } else {
            while (--n > 0) {
                node = node.prev;
            }
        }
        return node;
    }
}