import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class TecladoQuebrado {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextLine()) {
            String linha = scanner.nextLine();
            LinkedList<Character> resultado = new LinkedList<>();
            ListIterator<Character> iterator = resultado.listIterator();
            boolean home = false;

            for (char c : linha.toCharArray()) {
                if (c == '[') {
                    iterator = resultado.listIterator();
                } else if (c == ']') {
                    iterator = resultado.listIterator(resultado.size());
                } else {
                    iterator.add(c);
                }
            }

            StringBuilder sb = new StringBuilder();
            for (char c : resultado) {
                sb.append(c);
            }

            System.out.println(sb.toString());
        }

        scanner.close();
    }
}
