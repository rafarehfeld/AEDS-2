import java.util.Arrays;
import java.util.Scanner;

public class Seca {

    static class Property implements Comparable<Property> {
        int residents;
        int consumption;

        Property(int residents, int consumption) {
            this.residents = residents;
            this.consumption = consumption;
        }

        @Override
        public int compareTo(Property other) {
            int thisConsumptionPerResident = this.consumption / this.residents;
            int otherConsumptionPerResident = other.consumption / other.residents;
            return Integer.compare(thisConsumptionPerResident, otherConsumptionPerResident);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int city = 1;

        while (true) {
            int n = sc.nextInt();
            if (n == 0) break;

            Property[] properties = new Property[n];
            int totalResidents = 0, totalConsumption = 0;

            for (int i = 0; i < n; i++) {
                int residents = sc.nextInt();
                int consumption = sc.nextInt();
                properties[i] = new Property(residents, consumption);
                totalResidents += residents;
                totalConsumption += consumption;
            }

            Arrays.sort(properties);

            System.out.printf("Cidade# %d:\n", city++);
            for (int i = 0; i < n; i++) {
                if (i > 0) System.out.print(" ");
                System.out.printf("%d-%d", properties[i].residents, properties[i].consumption / properties[i].residents);
            }
            System.out.println();
            System.out.printf("Consumo medio: %.2f m3.\n\n", (double) totalConsumption / totalResidents);
        }
        
        sc.close();
    }
}
