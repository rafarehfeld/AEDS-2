import java.util.*;

public class NumberSorter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int N = scanner.nextInt();
        List<Integer> evens = new ArrayList<>();
        List<Integer> odds = new ArrayList<>();

        for (int i = 0; i < N; i++) {
            int num = scanner.nextInt();
            if (num % 2 == 0) {
                evens.add(num);
            } else {
                odds.add(num);
            }
        }

        // Sort evens in ascending order
        Collections.sort(evens);

        // Sort odds in descending order
        Collections.sort(odds, Collections.reverseOrder());

        // Print evens first
        for (int even : evens) {
            System.out.println(even);
        }

        // Print odds next
        for (int odd : odds) {
            System.out.println(odd);
        }

        scanner.close();
    }
}

