import java.util.Scanner;

public class ComposicaoDeJingles {

    public static double getDuracao(char nota) {
        switch (nota) {
            case 'W': return 1.0;
            case 'H': return 0.5;
            case 'Q': return 0.25;
            case 'E': return 0.125;
            case 'S': return 0.0625;
            case 'T': return 0.03125;
            case 'X': return 0.015625;
            default: return 0.0;
        }
    }

    public static int contarCompassosCorretos(String composicao) {
        int contadorCorretos = 0;
        double duracaoTotal = 0.0;
        
        for (int i = 0; i < composicao.length(); i++) {
            char c = composicao.charAt(i);
            if (c == '/') {
                if (duracaoTotal == 1.0) {
                    contadorCorretos++;
                }
                duracaoTotal = 0.0;
            } else {
                duracaoTotal += getDuracao(c);
            }
        }
        
        return contadorCorretos;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            String composicao = scanner.nextLine();
            if (composicao.equals("*")) {
                break;
            }
            int resultado = contarCompassosCorretos(composicao);
            System.out.println(resultado);
        }
        
        scanner.close();
    }
}

