import java.util.Scanner;

public class EmpilhamentodeBolas {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            int N = scanner.nextInt(); // Número de linhas da pilha
            if (N == 0) {
                break; // Se N for zero, termina o processamento
            }

            int[][] triangle = new int[N][];
            // Leitura dos valores do triângulo
            for (int i = 0; i < N; i++) {
                triangle[i] = new int[i + 1];
                for (int j = 0; j <= i; j++) {
                    triangle[i][j] = scanner.nextInt();
                }
            }

            // Array para armazenar os valores máximos acumulados
            int[] maxValues = new int[N];
            System.arraycopy(triangle[N-1], 0, maxValues, 0, N); // Copia a última linha para maxValues

            // Calculando os valores máximos de baixo para cima
            for (int i = N - 2; i >= 0; i--) {
                for (int j = 0; j <= i; j++) {
                    maxValues[j] = Math.max(maxValues[j], maxValues[j + 1]) + triangle[i][j];
                }
            }

            // O máximo valor acumulado está no topo do triângulo
            System.out.println(maxValues[0]);
        }

        scanner.close();
    }
}
