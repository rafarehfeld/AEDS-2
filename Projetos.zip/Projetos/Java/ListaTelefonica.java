import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class ListaTelefonica {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int N = Integer.parseInt(line.trim());
                if (N == 0) break;

                String[] phoneNumbers = new String[N];
                for (int i = 0; i < N; i++) {
                    phoneNumbers[i] = reader.readLine().trim();
                }

                int totalSavings = 0;

                for (int i = 1; i < N; i++) {
                    int commonPrefixLength = getCommonPrefixLength(phoneNumbers[i - 1], phoneNumbers[i]);
                    totalSavings += commonPrefixLength;
                }

                System.out.println(totalSavings);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static int getCommonPrefixLength(String str1, String str2) {
        int minLength = Math.min(str1.length(), str2.length());
        int commonLength = 0;

        for (int i = 0; i < minLength; i++) {
            if (str1.charAt(i) == str2.charAt(i)) {
                commonLength++;
            } else {
                break;
            }
        }

        return commonLength;
    }
}
