import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;

public class TellmetheFrequencies {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            boolean firstOutput = true;

            while ((line = reader.readLine()) != null) {
                if (!firstOutput) {
                    System.out.println();  // Print a blank line between different inputs
                }
                firstOutput = false;
                
                Map<Integer, Integer> frequencyMap = new TreeMap<>();

                // Calculate frequencies
                for (char c : line.toCharArray()) {
                    int ascii = (int) c;
                    frequencyMap.put(ascii, frequencyMap.getOrDefault(ascii, 0) + 1);
                }

                // Create a list to sort by frequency and then by ASCII value
                List<Map.Entry<Integer, Integer>> sortedList = new ArrayList<>(frequencyMap.entrySet());

                // Custom sorting logic
                Collections.sort(sortedList, new Comparator<Map.Entry<Integer, Integer>>() {
                    @Override
                    public int compare(Map.Entry<Integer, Integer> e1, Map.Entry<Integer, Integer> e2) {
                        int freqCompare = Integer.compare(e1.getValue(), e2.getValue());
                        if (freqCompare != 0) {
                            return freqCompare;
                        } else {
                            return Integer.compare(e2.getKey(), e1.getKey());  // Higher ASCII value first if same frequency
                        }
                    }
                });

                // Print the sorted frequencies
                for (Map.Entry<Integer, Integer> entry : sortedList) {
                    System.out.println(entry.getKey() + " " + entry.getValue());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
