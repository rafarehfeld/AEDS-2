import java.util.Scanner;
import java.util.Stack;

public class DiamondsAndSand {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        scanner.nextLine(); // Consume the remaining newline character
        
        for (int i = 0; i < N; i++) {
            String line = scanner.nextLine();
            System.out.println(countDiamonds(line));
        }
    }

    public static int countDiamonds(String line) {
        Stack<Character> stack = new Stack<>();
        int diamondCount = 0;
        
        for (char c : line.toCharArray()) {
            if (c == '<') {
                stack.push(c);
            } else if (c == '>' && !stack.isEmpty()) {
                stack.pop();
                diamondCount++;
            }
        }
        
        return diamondCount;
    }
}
