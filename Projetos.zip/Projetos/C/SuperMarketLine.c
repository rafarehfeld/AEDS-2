#include <stdio.h>
#include <stdlib.h>

// Cashier structure
typedef struct Cashier {
    int id;
    int processTime;
    int finishTime;
} Cashier;

// Function to compare cashiers by finish time
int compareCashiers(const void *a, const void *b) {
    const Cashier *cashierA = (const Cashier *)a;
    const Cashier *cashierB = (const Cashier *)b;

    if (cashierA->finishTime != cashierB->finishTime) {
        return cashierA->finishTime - cashierB->finishTime;
    }
    return cashierA->id - cashierB->id;
}

int main() {
    int N, M; // number of cashiers, number of clients
    scanf("%d %d", &N, &M);

    // Allocate memory for cashiers
    Cashier *cashiers = (Cashier *)malloc(N * sizeof(Cashier));
    if (cashiers == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    // Initialize cashiers
    for (int i = 0; i < N; i++) {
        int processTime;
        scanf("%d", &processTime);
        cashiers[i].id = i + 1;
        cashiers[i].processTime = processTime;
        cashiers[i].finishTime = 0;
    }

    // Process clients
    for (int j = 0; j < M; j++) {
        int items;
        scanf("%d", &items);

        // Find the cashier with the smallest finish time
        int minFinishTimeIndex = 0;
        for (int k = 1; k < N; k++) {
            if (cashiers[k].finishTime < cashiers[minFinishTimeIndex].finishTime) {
                minFinishTimeIndex = k;
            }
        }

        // Update finish time of the chosen cashier
        cashiers[minFinishTimeIndex].finishTime += items * cashiers[minFinishTimeIndex].processTime;
    }

    // Find the maximum finish time
    int maxFinishTime = 0;
    for (int i = 0; i < N; i++) {
        if (cashiers[i].finishTime > maxFinishTime) {
            maxFinishTime = cashiers[i].finishTime;
        }
    }

    printf("%d\n", maxFinishTime);

    // Free allocated memory
    free(cashiers);

    return 0;
}