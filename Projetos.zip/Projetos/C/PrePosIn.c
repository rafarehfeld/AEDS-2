#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Index(char arr[], int start, int end, char value) {
    for (int i = start; i <= end; i++) {
        if (arr[i] == value)
            return i;
    }
    return -1; 
}

void Postfixo(char pre[], char in[], int inStart, int inEnd, int *preIndex) {
    if (inStart > inEnd) 
        return;

    char root = pre[(*preIndex)++];
    int rootIndex = Index(in, inStart, inEnd, root);

    // subárvore esquerda
    Postfixo(pre, in, inStart, rootIndex - 1, preIndex);

    // subárvore direita
    Postfixo(pre, in, rootIndex + 1, inEnd, preIndex);

    printf("%c", root);
}

int main() {
    int x;
    scanf("%d", &x);

    while (x--) {
        int n;
        scanf("%d", &n);

        char pre[n + 1], in[n + 1];
        scanf("%s %s", pre, in);

        int preIndex = 0;

        Postfixo(pre, in, 0, n - 1, &preIndex);

        printf("\n");
    }

    return 0;
}
