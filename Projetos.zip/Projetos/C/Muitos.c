#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_YEARS 100
#define MAX_LENGTH 50

void skipLines(int n) {
    for (int i = 0; i < n; i++) {
        char buffer[MAX_LENGTH];
        fgets(buffer, MAX_LENGTH, stdin);
    }
}

int getMaxWrongCount(int counts[], int length) {
    int max = counts[0];
    for (int i = 1; i < length; i++) {
        if (counts[i] > max) {
            max = counts[i];
        }
    }
    return max;
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // to consume newline

    int wrong_counts[4] = {0}; // array to count the wrong guesses

    for (int year = 0; year < N; year++) {
        skipLines(1); // Skip "Palpites"

        // Read guesses
        char guesses[4][MAX_LENGTH];
        for (int i = 0; i < 4; i++) {
            fgets(guesses[i], MAX_LENGTH, stdin);
            guesses[i][strlen(guesses[i]) - 1] = '\0'; // remove newline character
        }

        skipLines(1); // Skip "Vencedores"

        // Read winners
        char winners[4][MAX_LENGTH];
        for (int i = 0; i < 4; i++) {
            fgets(winners[i], MAX_LENGTH, stdin);
            winners[i][strlen(winners[i]) - 1] = '\0'; // remove newline character
        }

        // Compare guesses with winners
        for (int i = 0; i < 4; i++) {
            if (strcmp(guesses[i], winners[i]) != 0) {
                wrong_counts[i]++;
            }
        }
    }

    // Output categories with the most wrong guesses
    for (int i = 0; i < 4; i++) {
        if (wrong_counts[i] == getMaxWrongCount(wrong_counts, 4)) {
            printf("%d ", i + 1);
        }
    }

    return 0;
}
