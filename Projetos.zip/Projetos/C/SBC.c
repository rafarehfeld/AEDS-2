#include <stdio.h>

int main() {
    int n, n2;

    while (scanf("%d", &n) != EOF) {
        n2 = n;
        int t[n];
        int c[n];
        int tempo = 0;

        for (int i = 0; i < n; i++) {
            scanf("%d %d", &t[i], &c[i]);
        }

        for (int j = 0; j < n2 - 1; j++) {
            if (c[j] < t[j + 1]) {
                tempo += c[j] + (t[j + 1] - c[j]);
            } else {
                tempo += c[j];
            }
        }

        printf("%d\n", tempo);
    }

    return 0;
}
