#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int id;
    struct Node *prev;
    struct Node *next;
} Node;

Node* fill(int size) {
    Node *node, *nodePrev = NULL, *start = NULL;

    for (int i = 1; i <= size; ++i) {
        node = (Node*)malloc(sizeof(Node));
        node->id = i;
        node->next = NULL;
        node->prev = NULL;

        if (start == NULL) {
            start = node;
        } else {
            nodePrev->next = node;
            node->prev = nodePrev;
        }

        nodePrev = node;
    }

    start->prev = nodePrev;
    nodePrev->next = start;

    return start;
}

Node* deleteNode(Node *list, Node *reg) {
    Node *nodePrev = reg->prev;
    Node *nodeNext = reg->next;

    if (reg == list) {
        list = list->next;
        nodePrev->next = list;
        list->prev = nodePrev;
    } else {
        nodePrev->next = nodeNext;
        nodeNext->prev = nodePrev;
    }

    free(reg);

    return list;
}

int count(Node *list) {
    int i = 1;
    Node *node = list;
    while (list != node->next) {
        node = node->next;
        i++;
    }
    return i;
}

Node* traverse(Node *list, int n, int direction) {
    Node *node = list;
    if (direction == 0) {
        while (--n > 0) {
            node = node->next;
        }
    } else {
        while (--n > 0) {
            node = node->prev;
        }
    }
    return node;
}

int main() {
    int n, k, m;

    while (1) {
        scanf("%d %d %d", &n, &k, &m);
        if (n == 0 && k == 0 && m == 0) {
            break;
        }

        Node *list = fill(n);
        Node *K = list;
        Node *M = list->prev;

        while (count(list) > 2) {
            K = traverse(K, k, 0);
            M = traverse(M, m, 1);

            Node *auxK = (K->next == M) ? M->next : K->next;
            Node *auxM = (M->prev == K) ? K->prev : M->prev;

            if (K == M) {
                printf("%3d,", M->id);
                list = deleteNode(list, K);
            } else {
                printf("%3d%3d,", K->id, M->id);
                list = deleteNode(list, M);
                list = deleteNode(list, K);
            }

            K = auxK;
            M = auxM;
        }

        if (count(list) == 2) {
            K = traverse(K, k, 0);
            M = traverse(M, m, 1);

            if (K == M) {
                printf("%3d,%3d\n", K->id, K->next->id);
            } else {
                printf("%3d%3d\n", K->id, K->next->id);
            }
        } else {
            printf("%3d\n", list->id);
        }

        // Free memory
        Node *current = list;
        Node *temp;
        do {
            temp = current;
            current = current->next;
            free(temp);
        } while (current != list);
    }

    return 0;
}