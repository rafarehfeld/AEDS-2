#include <stdio.h>
#include <stdlib.h>

#define MAXN 100000

int arr[MAXN];
int segTree[4 * MAXN];

void build(int node, int start, int end) {
    if (start == end) {
        if (arr[start] > 0)
            segTree[node] = 1;
        else if (arr[start] < 0)
            segTree[node] = -1;
        else
            segTree[node] = 0;
    } else {
        int mid = (start + end) / 2;
        build(2 * node, start, mid);
        build(2 * node + 1, mid + 1, end);
        segTree[node] = segTree[2 * node] * segTree[2 * node + 1];
    }
}

void update(int node, int start, int end, int idx, int val) {
    if (start == end) {
        if (val > 0)
            segTree[node] = 1;
        else if (val < 0)
            segTree[node] = -1;
        else
            segTree[node] = 0;
    } else {
        int mid = (start + end) / 2;
        if (start <= idx && idx <= mid) {
            update(2 * node, start, mid, idx, val);
        } else {
            update(2 * node + 1, mid + 1, end, idx, val);
        }
        segTree[node] = segTree[2 * node] * segTree[2 * node + 1];
    }
}

int query(int node, int start, int end, int L, int R) {
    if (R < start || end < L) {
        return 1;
    }
    if (L <= start && end <= R) {
        return segTree[node];
    }
    int mid = (start + end) / 2;
    int leftQuery = query(2 * node, start, mid, L, R);
    int rightQuery = query(2 * node + 1, mid + 1, end, L, R);
    return leftQuery * rightQuery;
}

int main() {
    int N, K;
    while (scanf("%d %d", &N, &K) != EOF) {
        for (int i = 0; i < N; i++) {
            scanf("%d", &arr[i]);
        }
        build(1, 0, N - 1);
        
        char result[K];
        int resultIndex = 0;
        
        for (int i = 0; i < K; i++) {
            char command;
            int I, V;
            scanf(" %c %d %d", &command, &I, &V);
            if (command == 'C') {
                update(1, 0, N - 1, I - 1, V);
            } else if (command == 'P') {
                int product = query(1, 0, N - 1, I - 1, V - 1);
                if (product > 0) {
                    result[resultIndex++] = '+';
                } else if (product < 0) {
                    result[resultIndex++] = '-';
                } else {
                    result[resultIndex++] = '0';
                }
            }
        }
        result[resultIndex] = '\0';
        printf("%s\n", result);
    }
    return 0;
}
