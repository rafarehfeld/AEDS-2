#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_EXPR_SIZE 1001

int precedence(char op) {
    switch (op) {
        case '^': return 6;
        case '*': case '/': return 5;
        case '+': case '-': return 4;
        case '>': case '<': case '=': case '#': return 3;
        case '.': return 2; // AND
        case '|': return 1; // OR
        default: return -1;
    }
}

int isOperator(char c) {
    return strchr("^*/+-><=#.|", c) != NULL;
}

int isValidCharacter(char c) {
    return isalnum(c) || isOperator(c) || c == '(' || c == ')';
}

void infixToPostfix(char* expression, char* result) {
    char stack[MAX_EXPR_SIZE];
    int top = -1;
    int k = 0;
    int lastWasOperand = 0;

    for (int i = 0; expression[i] != '\0'; i++) {
        char c = expression[i];

        if (isalnum(c)) {
            result[k++] = c;
            lastWasOperand = 1;
        } else if (c == '(') {
            stack[++top] = c;
            lastWasOperand = 0;
        } else if (c == ')') {
            while (top != -1 && stack[top] != '(') {
                result[k++] = stack[top--];
            }
            if (top == -1 || stack[top] != '(') {
                strcpy(result, "Syntax Error!");
                return;
            }
            top--;
            lastWasOperand = 1;
        } else if (isOperator(c)) {
            if (!lastWasOperand) {
                strcpy(result, "Syntax Error!");
                return;
            }
            while (top != -1 && precedence(c) <= precedence(stack[top])) {
                result[k++] = stack[top--];
            }
            stack[++top] = c;
            lastWasOperand = 0;
        } else {
            strcpy(result, "Lexical Error!");
            return;
        }
    }

    while (top != -1) {
        if (stack[top] == '(' || stack[top] == ')') {
            strcpy(result, "Syntax Error!");
            return;
        }
        result[k++] = stack[top--];
    }

    result[k] = '\0';
}

int main() {
    char expression[MAX_EXPR_SIZE];
    char result[MAX_EXPR_SIZE];

    while (fgets(expression, sizeof(expression), stdin) != NULL) {
        // Remove the newline character if present
        expression[strcspn(expression, "\n")] = '\0';

        // Check for lexical errors first
        int valid = 1;
        for (int i = 0; expression[i] != '\0'; i++) {
            if (!isValidCharacter(expression[i])) {
                valid = 0;
                break;
            }
        }

        if (!valid) {
            printf("Lexical Error!\n");
        } else {
            infixToPostfix(expression, result);
            printf("%s\n", result);
        }
    }

    return 0;
}
