#include <stdio.h>
#include <stdbool.h>

typedef struct {
    int inicio;
    int saida;
} Carro;

// Função de comparação para a fila de prioridade (PriorityQueue)
int compare(const void *a, const void *b) {
    return ((Carro *)a)->saida - ((Carro *)b)->saida;
}

int main() {
    int n, k;

    while (1) {
        scanf("%d %d", &n, &k);
        if (n == 0 && k == 0) break;

        Carro vet[n];
        for (int i = 0; i < n; i++) {
            int c, s;
            scanf("%d %d", &c, &s);
            vet[i].inicio = c;
            vet[i].saida = s;
        }

        bool possivel = true;
        Carro estacionamento[n];
        int tamanho_estacionamento = 0;

        qsort(vet, n, sizeof(Carro), compare);

        for (int i = 0; i < n; i++) {
            Carro carroAtual = vet[i];
            
            if (vet[i].saida > 10) {
                possivel = false;
                break;
            }

            // Remove os carros que já podem sair antes de tentar estacionar o próximo carro
            while (tamanho_estacionamento > 0 && estacionamento[0].saida <= carroAtual.inicio) {
                for (int j = 0; j < tamanho_estacionamento - 1; j++) {
                    estacionamento[j] = estacionamento[j + 1];
                }
                tamanho_estacionamento--;
            }

            // Verifica se ainda há espaço no estacionamento
            if (tamanho_estacionamento < k) {
                estacionamento[tamanho_estacionamento++] = carroAtual;
            } else {
                possivel = false;
                break;
            }
        }

        if (possivel) {
            printf("Sim\n");
        } else {
            printf("Nao\n");
        }
    }

    return 0;
}
