#include <stdio.h>
#include <stdlib.h>

int compareAsc(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int compareDesc(const void *a, const void *b) {
    return (*(int*)b - *(int*)a);
}

int main() {
    int N;
    scanf("%d", &N);

    int *evens = (int *)malloc(N * sizeof(int));
    int *odds = (int *)malloc(N * sizeof(int));
    int evenCount = 0, oddCount = 0;

    for (int i = 0; i < N; i++) {
        int num;
        scanf("%d", &num);
        if (num % 2 == 0) {
            evens[evenCount++] = num;
        } else {
            odds[oddCount++] = num;
        }
    }

    qsort(evens, evenCount, sizeof(int), compareAsc);
    qsort(odds, oddCount, sizeof(int), compareDesc);

    for (int i = 0; i < evenCount; i++) {
        printf("%d\n", evens[i]);
    }
    for (int i = 0; i < oddCount; i++) {
        printf("%d\n", odds[i]);
    }

    free(evens);
    free(odds);
    return 0;
}


