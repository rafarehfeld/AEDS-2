#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int cmpfunc(const void *a, const void *b) {
    return (*(char *)a - *(char *)b);
}

int next_permutation(char *str, int length) {
    int i = length - 1;
    while (i > 0 && str[i - 1] >= str[i]) {
        i--;
    }
    if (i <= 0) {
        return 0;
    }

    int j = length - 1;
    while (str[j] <= str[i - 1]) {
        j--;
    }

    char temp = str[i - 1];
    str[i - 1] = str[j];
    str[j] = temp;

    j = length - 1;
    while (i < j) {
        temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }

    return 1;
}

int main() {
    int n;
    scanf("%d", &n);
    char str[11];

    for (int i = 0; i < n; i++) {
        scanf("%s", str);
        int length = strlen(str);

        qsort(str, length, sizeof(char), cmpfunc);

        do {
            printf("%s\n", str);
        } while (next_permutation(str, length));

        if (i < n - 1) {
            printf("\n");
        }
    }

    return 0;
}
