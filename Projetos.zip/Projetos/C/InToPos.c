#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 305

typedef struct {
    char data[MAX_SIZE];
    int top;
} Stack;

void push(Stack *stack, char c) {
    if (stack->top == MAX_SIZE - 1) {
        printf("Stack overflow\n");
        exit(EXIT_FAILURE);
    }
    stack->data[++stack->top] = c;
}

char pop(Stack *stack) {
    if (stack->top == -1) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }
    return stack->data[stack->top--];
}

char peek(Stack *stack) {
    return stack->data[stack->top];
}

int isEmpty(Stack *stack) {
    return stack->top == -1;
}

int isOperand(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');
}

int precedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '^':
            return 3;
        default:
            return -1;
    }
}

void infixToPostfix(char *infix, char *postfix) {
    Stack stack;
    stack.top = -1;
    int i = 0, j = 0;

    while (infix[i] != '\0') {
        char c = infix[i++];

        if (isOperand(c)) {
            postfix[j++] = c;
        } else if (c == '(') {
            push(&stack, c);
        } else if (c == ')') {
            while (!isEmpty(&stack) && peek(&stack) != '(') {
                postfix[j++] = pop(&stack);
            }
            pop(&stack); // Pop '('
        } else {
            while (!isEmpty(&stack) && precedence(c) <= precedence(peek(&stack))) {
                postfix[j++] = pop(&stack);
            }
            push(&stack, c);
        }
    }

    while (!isEmpty(&stack)) {
        postfix[j++] = pop(&stack);
    }

    postfix[j] = '\0'; // Null terminate the string
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // Consume the newline

    for (int i = 0; i < N; i++) {
        char infix[MAX_SIZE], postfix[MAX_SIZE];
        fgets(infix, MAX_SIZE, stdin);
        infix[strcspn(infix, "\n")] = '\0'; // Remove newline if present
        infixToPostfix(infix, postfix);
        printf("%s\n", postfix);
    }

    return 0;
}
