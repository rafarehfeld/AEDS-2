#include <stdio.h>
#include <string.h>

void print_frequencies(const int *freq) {
    int i, j;
    int count[1000], char_val[1000], index = 0;

    for (i = 0; i < 128; i++) {
        if (freq[i] > 0) {
            count[index] = freq[i];
            char_val[index] = i;
            index++;
        }
    }

    for (i = 0; i < index - 1; i++) {
        for (j = i + 1; j < index; j++) {
            if (count[i] > count[j] || (count[i] == count[j] && char_val[i] < char_val[j])) {
                int temp_count = count[i];
                int temp_char_val = char_val[i];
                count[i] = count[j];
                char_val[i] = char_val[j];
                count[j] = temp_count;
                char_val[j] = temp_char_val;
            }
        }
    }

    for (i = 0; i < index; i++) {
        printf("%d %d\n", char_val[i], count[i]);
    }
}

int main() {
    char line[1001];
    int freq[128];
    int first = 1;

    while (fgets(line, sizeof(line), stdin)) {
        memset(freq, 0, sizeof(freq));

        for (int i = 0; line[i]; i++) {
            if (line[i] >= 32 && line[i] < 128) {
                freq[(int)line[i]]++;
            }
        }

        if (!first) {
            printf("\n");
        }
        first = 0;

        print_frequencies(freq);
    }

    return 0;
}
