#include <stdio.h>
#include <stdlib.h>

#define MAXN 100000

int array[MAXN];
int segmentTree[4 * MAXN];

// Function to get the sign of a value
int getSign(int value) {
    if (value > 0) return 1;
    if (value < 0) return -1;
    return 0;
}

// Function to build the segment tree
void build(int node, int start, int end) {
    if (start == end) {
        segmentTree[node] = getSign(array[start]);
    } else {
        int mid = (start + end) / 2;
        int leftChild = 2 * node + 1;
        int rightChild = 2 * node + 2;
        build(leftChild, start, mid);
        build(rightChild, mid + 1, end);
        segmentTree[node] = segmentTree[leftChild] * segmentTree[rightChild];
    }
}

// Function to update a value in the segment tree
void update(int node, int start, int end, int idx, int value) {
    if (start == end) {
        array[idx] = value;
        segmentTree[node] = getSign(value);
    } else {
        int mid = (start + end) / 2;
        int leftChild = 2 * node + 1;
        int rightChild = 2 * node + 2;
        if (start <= idx && idx <= mid) {
            update(leftChild, start, mid, idx, value);
        } else {
            update(rightChild, mid + 1, end, idx, value);
        }
        segmentTree[node] = segmentTree[leftChild] * segmentTree[rightChild];
    }
}

// Function to get the product of a range in the segment tree
int product(int node, int start, int end, int l, int r) {
    if (r < start || end < l) {
        return 1;
    }
    if (l <= start && end <= r) {
        return segmentTree[node];
    }
    int mid = (start + end) / 2;
    int leftChild = 2 * node + 1;
    int rightChild = 2 * node + 2;
    int leftProduct = product(leftChild, start, mid, l, r);
    int rightProduct = product(rightChild, mid + 1, end, l, r);
    return leftProduct * rightProduct;
}

int main() {
    int N, K;
    while (scanf("%d %d", &N, &K) != EOF) {
        for (int i = 0; i < N; i++) {
            scanf("%d", &array[i]);
        }

        build(0, 0, N - 1);

        char command;
        int I, J;
        char result[K + 1];
        int resultIndex = 0;
        for (int i = 0; i < K; i++) {
            scanf(" %c %d %d", &command, &I, &J);
            if (command == 'C') {
                update(0, 0, N - 1, I - 1, J); // Convert to 0-based index
            } else if (command == 'P') {
                int prod = product(0, 0, N - 1, I - 1, J - 1); // Convert to 0-based index
                if (prod > 0) {
                    result[resultIndex++] = '+';
                } else if (prod < 0) {
                    result[resultIndex++] = '-';
                } else {
                    result[resultIndex++] = '0';
                }
            }
        }
        result[resultIndex] = '\0';
        printf("%s\n", result);
    }

    return 0;
}
