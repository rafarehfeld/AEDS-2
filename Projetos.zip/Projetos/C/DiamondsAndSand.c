#include <stdio.h>
#include <string.h>

int countDiamonds(char *line) {
    int stack = 0;
    int diamondCount = 0;

    for (int i = 0; line[i] != '\0'; i++) {
        if (line[i] == '<') {
            stack++;
        } else if (line[i] == '>' && stack > 0) {
            stack--;
            diamondCount++;
        }
    }

    return diamondCount;
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // Consume the newline character after the number of test cases

    for (int i = 0; i < N; i++) {
        char line[1001];
        fgets(line, sizeof(line), stdin);
        // Remove the newline character if present
        line[strcspn(line, "\n")] = '\0';
        printf("%d\n", countDiamonds(line));
    }

    return 0;
}

