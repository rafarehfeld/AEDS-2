#include <stdio.h>
#include <stdlib.h>

int compare(const void *a, const void *b, void *m) {
    int num1 = *(int*)a;
    int num2 = *(int*)b;
    int M = *(int*)m;

    int mod1 = num1 % M;
    int mod2 = num2 % M;

    if (mod1 < 0) mod1 += M;
    if (mod2 < 0) mod2 += M;

    if (mod1 != mod2) {
        return mod1 - mod2;
    }

    if ((num1 % 2 != 0) && (num2 % 2 == 0)) {
        return -1;
    }
    if ((num1 % 2 == 0) && (num2 % 2 != 0)) {
        return 1;
    }
    if ((num1 % 2 != 0) && (num2 % 2 != 0)) {
        return num2 - num1;
    }
    if ((num1 % 2 == 0) && (num2 % 2 == 0)) {
        return num1 - num2;
    }

    return 0;
}

int main() {
    int N, M;
    while (scanf("%d %d", &N, &M) == 2 && (N != 0 || M != 0)) {
        printf("%d %d\n", N, M);
        int numbers[N];
        for (int i = 0; i < N; i++) {
            scanf("%d", &numbers[i]);
        }

        qsort_r(numbers, N, sizeof(int), compare, &M);

        for (int i = 0; i < N; i++) {
            printf("%d\n", numbers[i]);
        }
    }
    printf("0 0\n");
    return 0;
}
