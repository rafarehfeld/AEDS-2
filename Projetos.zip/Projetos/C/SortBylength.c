#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STRINGS 50
#define MAX_LENGTH 51

typedef struct {
    char str[MAX_LENGTH];
    int original_index;
} String;

int compare(const void *a, const void *b) {
    String *strA = (String *)a;
    String *strB = (String *)b;
    int lenA = strlen(strA->str);
    int lenB = strlen(strB->str);

    if (lenA != lenB) {
        return lenA - lenB;
    }
    return strA->original_index - strB->original_index;
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // Consume newline after integer input

    for (int i = 0; i < N; i++) {
        String strings[MAX_STRINGS];
        int count = 0;

        while (1) {
            if (scanf("%50s", strings[count].str) == EOF) {
                break;
            }
            strings[count].original_index = count;
            count++;
            char c = getchar();
            if (c == '\n' || c == EOF) {
                break;
            }
        }

        qsort(strings, count, sizeof(String), compare);

        for (int j = 0; j < count; j++) {
            if (j > 0) {
                printf(" ");
            }
            printf("%s", strings[j].str);
        }
        printf("\n");
    }

    return 0;
}
