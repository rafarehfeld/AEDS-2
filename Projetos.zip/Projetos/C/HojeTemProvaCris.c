#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAMES 100
#define MAX_NAME_LENGTH 21

// Function to swap two strings
void swap(char **a, char **b) {
    char *temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int n, k, instance = 1;

    while (1) {
        scanf("%d %d", &n, &k);
        if (n == 0 && k == 0) break;

        char **names = (char **)malloc(n * sizeof(char *));
        for (int i = 0; i < n; i++) {
            names[i] = (char *)malloc(MAX_NAME_LENGTH * sizeof(char));
            scanf("%s", names[i]);
        }

        for (int i = 0; i < n - 1 && k > 0; i++) {
            int pos = i;
            for (int j = i + 1; j < n && j - i <= k; j++) {
                if (strcmp(names[j], names[pos]) < 0) {
                    pos = j;
                }
            }
            for (int j = pos; j > i; j--) {
                swap(&names[j], &names[j - 1]);
                k--;
            }
        }

        printf("Instancia %d\n", instance++);
        for (int i = 0; i < n; i++) {
            printf("%s ", names[i]);
        }
        printf("\n\n");

        for (int i = 0; i < n; i++) {
            free(names[i]);
        }
        free(names);
    }

    return 0;
}
