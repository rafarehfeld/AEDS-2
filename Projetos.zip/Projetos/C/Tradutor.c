#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct{
    char pais[50];
    char traducao[100];
}Linguas;



int main(){
    Linguas vet[24];

    strcpy(vet[0].pais,"brasil");
    strcpy(vet[1].pais,"alemanha");
    strcpy(vet[2].pais,"austria");
    strcpy(vet[3].pais,"coreia");
    strcpy(vet[4].pais,"espanha");
    strcpy(vet[5].pais,"grecia");
    strcpy(vet[6].pais,"estados-unidos");
    strcpy(vet[7].pais,"inglaterra");
    strcpy(vet[8].pais,"australia");
    strcpy(vet[9].pais,"portugal");
    strcpy(vet[10].pais,"suecia");
    strcpy(vet[11].pais,"turquia");
    strcpy(vet[12].pais,"argentina");
    strcpy(vet[13].pais,"chile");
    strcpy(vet[14].pais,"mexico");
    strcpy(vet[15].pais,"antartida");
    strcpy(vet[16].pais,"canada");
    strcpy(vet[17].pais,"irlanda");
    strcpy(vet[18].pais,"belgica");
    strcpy(vet[19].pais,"italia");
    strcpy(vet[20].pais,"libia");
    strcpy(vet[21].pais,"siria");
    strcpy(vet[22].pais,"marrocos");
    strcpy(vet[23].pais,"japao");

    strcpy(vet[0].traducao,"Feliz Natal!");
    strcpy(vet[1].traducao,"Frohliche Weihnachten!");
    strcpy(vet[2].traducao,"Frohe Weihnacht!");
    strcpy(vet[3].traducao,"Chuk Sung Tan!");
    strcpy(vet[4].traducao,"Feliz Navidad!");
    strcpy(vet[5].traducao,"Kala Christougena!");
    strcpy(vet[6].traducao,"Merry Christmas!");
    strcpy(vet[7].traducao,"Merry Christmas!");
    strcpy(vet[8].traducao,"Merry Christmas!");
    strcpy(vet[9].traducao,"Feliz Natal!");
    strcpy(vet[10].traducao,"God Jul!");
    strcpy(vet[11].traducao,"Mutlu Noeller");
    strcpy(vet[12].traducao,"Feliz Navidad!");
    strcpy(vet[13].traducao,"Feliz Navidad!");
    strcpy(vet[14].traducao,"Feliz Navidad!");
    strcpy(vet[15].traducao,"Merry Christmas!");
    strcpy(vet[16].traducao,"Merry Christmas!");
    strcpy(vet[17].traducao,"Nollaig Shona Dhuit!");
    strcpy(vet[18].traducao,"Zalig Kerstfeest!");
    strcpy(vet[19].traducao,"Buon Natale!");
    strcpy(vet[20].traducao,"Buon Natale!");
    strcpy(vet[21].traducao,"Milad Mubarak!");
    strcpy(vet[22].traducao,"Milad Mubarak!");
    strcpy(vet[23].traducao,"Merii Kurisumasu!");

    for(int i=0;i<4;i++){
        int teste = 0;
        char entrada[50];
        scanf("%[^\n]",entrada);
        getchar();
        for (int j = 0; j < 24; j++)
        {
            if(strcmp(entrada,vet[j].pais)==0){
                printf("%s\n",vet[j].traducao);
                teste =1;
            }
        }
        if(teste == 0){
            printf("--- NOT FOUND ---\n");
        }
        
    }

    return 0;
}