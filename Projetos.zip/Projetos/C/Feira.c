#include <stdio.h>
#include <string.h>

#define MAX_PRODUCTS 100

typedef struct {
    char name[51];
    double price;
} Product;

int main() {
    int N;
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        int M;
        scanf("%d", &M);

        Product products[MAX_PRODUCTS];

        for (int j = 0; j < M; j++) {
            scanf("%s %lf", products[j].name, &products[j].price);
        }

        int P;
        scanf("%d", &P);

        double totalCost = 0.0;

        for (int j = 0; j < P; j++) {
            char productName[51];
            int quantity;
            scanf("%s %d", productName, &quantity);

            for (int k = 0; k < M; k++) {
                if (strcmp(products[k].name, productName) == 0) {
                    totalCost += products[k].price * quantity;
                    break;
                }
            }
        }

        printf("R$ %.2f\n", totalCost);
    }

    return 0;
}
