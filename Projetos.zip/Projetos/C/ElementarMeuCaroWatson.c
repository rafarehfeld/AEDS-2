#include <stdio.h>
#include <stdbool.h>

void solve(int n, int arr[]) {
    bool visited[n];
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }

    int swaps = 0;

    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            int cycle_length = 0;
            int j = i;
            while (!visited[j]) {
                visited[j] = true;
                j = arr[j] - 1;
                cycle_length++;
            }
            if (cycle_length > 0) {
                swaps += (cycle_length - 1);
            }
        }
    }

    printf("%d\n", swaps);
}

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        int n;
        scanf("%d", &n);
        int arr[n];
        for (int i = 0; i < n; i++) {
            scanf("%d", &arr[i]);
        }
        solve(n, arr);
    }
    return 0;
}
