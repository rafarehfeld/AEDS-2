#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SPECIES_NAME_LENGTH 31
#define MAX_SPECIES_COUNT 10000
#define MAX_LINE_LENGTH 100

typedef struct {
    char name[MAX_SPECIES_NAME_LENGTH];
    int count;
} Species;

int compareSpecies(const void *a, const void *b) {
    return strcmp(((Species*)a)->name, ((Species*)b)->name);
}

void processTestCase() {
    Species species[MAX_SPECIES_COUNT];
    int speciesCount = 0;
    int totalTrees = 0;
    char line[MAX_LINE_LENGTH];

    while (fgets(line, sizeof(line), stdin) != NULL) {
        if (line[0] == '\n') break; // end of current test case

        line[strcspn(line, "\n")] = 0; // remove the newline character

        // Check if species already exists
        int found = 0;
        for (int i = 0; i < speciesCount; i++) {
            if (strcmp(species[i].name, line) == 0) {
                species[i].count++;
                found = 1;
                break;
            }
        }

        // If species not found, add new species
        if (!found) {
            strcpy(species[speciesCount].name, line);
            species[speciesCount].count = 1;
            speciesCount++;
        }

        totalTrees++;
    }

    // Sort species alphabetically
    qsort(species, speciesCount, sizeof(Species), compareSpecies);

    // Print results
    for (int i = 0; i < speciesCount; i++) {
        double percentage = (species[i].count * 100.0) / totalTrees;
        printf("%s %.4f\n", species[i].name, percentage);
    }
}

int main() {
    char line[MAX_LINE_LENGTH];
    int testCases;

    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &testCases);
    fgets(line, sizeof(line), stdin); // consume the blank line after the number of test cases

    for (int t = 0; t < testCases; t++) {
        processTestCase();
        if (t < testCases - 1) {
            printf("\n");
        }
    }

    return 0;
}
