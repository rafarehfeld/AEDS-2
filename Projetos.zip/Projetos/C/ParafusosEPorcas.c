#include <stdio.h>
#include <stdlib.h>

#define MAX_SHELVES 10000

int main() {
    int N, X, Y, Num;
    int shelves[MAX_SHELVES];
    int currentPosition;

    while (scanf("%d", &N) != EOF) {
        // Inicializa o array com -1 para indicar prateleiras vazias
        currentPosition = 0;
        
        for (int i = 0; i < N; i++) {
            scanf("%d %d", &X, &Y);
            for (int j = X; j <= Y; j++) {
                shelves[currentPosition++] = j;
            }
        }
        
        scanf("%d", &Num);

        int found = 0, firstIndex = -1, lastIndex = -1;
        
        for (int i = 0; i < currentPosition; i++) {
            if (shelves[i] == Num) {
                if (!found) {
                    firstIndex = i;
                }
                found = 1;
                lastIndex = i;
            }
        }
        
        if (found) {
            printf("%d found from %d to %d\n", Num, firstIndex, lastIndex);
        } else {
            printf("%d not found\n", Num);
        }
    }
    
    return 0;
}
