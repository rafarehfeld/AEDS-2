#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int residents;
    int consumption;
} Property;

int compare(const void *a, const void *b) {
    Property *propertyA = (Property *)a;
    Property *propertyB = (Property *)b;
    int consumptionA = propertyA->consumption / propertyA->residents;
    int consumptionB = propertyB->consumption / propertyB->residents;
    return consumptionA - consumptionB;
}

int main() {
    int n, city = 1;

    while (scanf("%d", &n) && n != 0) {
        Property properties[n];
        int total_residents = 0, total_consumption = 0;

        for (int i = 0; i < n; i++) {
            scanf("%d %d", &properties[i].residents, &properties[i].consumption);
            total_residents += properties[i].residents;
            total_consumption += properties[i].consumption;
        }

        qsort(properties, n, sizeof(Property), compare);

        printf("Cidade# %d:\n", city++);
        for (int i = 0; i < n; i++) {
            printf("%d-%d", properties[i].residents, properties[i].consumption / properties[i].residents);
            if (i < n - 1) printf(" ");
        }
        printf("\nConsumo medio: %.2lf m3.\n\n", (double)total_consumption / total_residents);
    }

    return 0;
}
