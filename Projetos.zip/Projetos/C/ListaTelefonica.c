#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to get the length of the common prefix between two strings
int getCommonPrefixLength(const char *str1, const char *str2) {
    int commonLength = 0;
    while (str1[commonLength] && str1[commonLength] == str2[commonLength]) {
        commonLength++;
    }
    return commonLength;
}

int main() {
    char buffer[201];  // Buffer to read each phone number (200 characters max + null terminator)
    int N;  // Number of phone numbers in the current test case
    
    // Read input until EOF
    while (scanf("%d", &N) != EOF) {
        if (N == 0) break;

        char **phoneNumbers = (char **)malloc(N * sizeof(char *));
        for (int i = 0; i < N; i++) {
            phoneNumbers[i] = (char *)malloc(201 * sizeof(char));
            scanf("%s", phoneNumbers[i]);
        }

        int totalSavings = 0;

        for (int i = 1; i < N; i++) {
            int commonPrefixLength = getCommonPrefixLength(phoneNumbers[i - 1], phoneNumbers[i]);
            totalSavings += commonPrefixLength;
        }

        printf("%d\n", totalSavings);

        // Free allocated memory
        for (int i = 0; i < N; i++) {
            free(phoneNumbers[i]);
        }
        free(phoneNumbers);
    }

    return 0;
}
