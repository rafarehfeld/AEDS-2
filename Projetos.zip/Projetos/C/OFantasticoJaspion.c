#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 81

typedef struct {
    char jap[51];
    char por[81];
} Dicionario;

void traduzir(int M, int N, Dicionario *dicionario, char **musica) {
    for (int i = 0; i < N; i++) {
        char *palavra = strtok(musica[i], " ");
        while (palavra != NULL) {
            int traduzida = 0;
            for (int j = 0; j < M; j++) {
                if (strcmp(palavra, dicionario[j].jap) == 0) {
                    printf("%s", dicionario[j].por);
                    traduzida = 1;
                    break;
                }
            }
            if (!traduzida) {
                printf("%s", palavra);
            }
            palavra = strtok(NULL, " ");
            if (palavra != NULL) {
                printf(" ");
            }
        }
        printf("\n");
    }
}

int main() {
    int T;
    scanf("%d", &T);

    while (T--) {
        int M, N;
        scanf("%d %d", &M, &N);

        Dicionario *dicionario = (Dicionario *)malloc(M * sizeof(Dicionario));
        char **musica = (char **)malloc(N * sizeof(char *));

        for (int i = 0; i < M; i++) {
            scanf("%s", dicionario[i].jap);
            getchar(); // Para capturar o newline após a palavra japonesa
            fgets(dicionario[i].por, 81, stdin);
            dicionario[i].por[strcspn(dicionario[i].por, "\n")] = '\0'; // Remover o newline
        }

        getchar(); // Para capturar o newline antes das linhas da música
        for (int i = 0; i < N; i++) {
            musica[i] = (char *)malloc(MAX_LINE_LENGTH * sizeof(char));
            fgets(musica[i], MAX_LINE_LENGTH, stdin);
            musica[i][strcspn(musica[i], "\n")] = '\0'; // Remover o newline
        }

        traduzir(M, N, dicionario, musica);

        free(dicionario);
        for (int i = 0; i < N; i++) {
            free(musica[i]);
        }
        free(musica);

        if (T > 0) {
            printf("\n");
        }
    }

    return 0;
}

