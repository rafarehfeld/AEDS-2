#include <stdio.h>
#include <stdlib.h>

// Function prototype
int canReachWithinNDays(int currentFollowers, int targetFollowers, int D[], int days);

int main() {
    // Read N and M
    int N, M;
    scanf("%d %d", &N, &M);

    // Read the last 30 days followers count
    int D[30];
    for (int i = 0; i < 30; i++) {
        scanf("%d", &D[i]);
    }

    // Binary search for the minimum number of days required
    int low = 0;
    int high = 100000; // starting with a high enough upper bound

    while (low < high) {
        int mid = low + (high - low) / 2;

        if (canReachWithinNDays(N, M, D, mid)) {
            high = mid;
        } else {
            low = mid + 1;
        }
    }

    printf("%d\n", low);

    return 0;
}

// Function to check if we can reach at least M followers within N days
int canReachWithinNDays(int currentFollowers, int targetFollowers, int D[], int days) {
    long totalFollowers = currentFollowers;

    for (int i = (30 - days > 0) ? 30 - days : 0; i < 30; i++) {
        totalFollowers += D[i];
        if (totalFollowers >= targetFollowers) {
            return 1; // true
        }
    }

    return 0; // false
}