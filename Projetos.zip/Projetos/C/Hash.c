#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct Node {
    int key;
    struct Node *next;
} Node;

Node *createNode(int key) {
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->key = key;
    newNode->next = NULL;
    return newNode;
}

void insert(Node *hashTable[], int key, int M) {
    int index = key % M;
    Node *newNode = createNode(key);
    if (hashTable[index] == NULL) {
        hashTable[index] = newNode;
    } else {
        Node *temp = hashTable[index];
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
}

void printHashTable(Node *hashTable[], int M) {
    for (int i = 0; i < M; i++) {
        printf("%d ->", i);
        Node *temp = hashTable[i];
        while (temp != NULL) {
            printf(" %d ->", temp->key);
            temp = temp->next;
        }
        printf(" \\\n");
    }
}

void freeHashTable(Node *hashTable[], int M) {
    for (int i = 0; i < M; i++) {
        Node *temp = hashTable[i];
        while (temp != NULL) {
            Node *toFree = temp;
            temp = temp->next;
            free(toFree);
        }
    }
}

int main() {
    int N;
    scanf("%d", &N);

    for (int i = 0; i < N; i++) {
        int M, C;
        scanf("%d %d", &M, &C);

        Node *hashTable[MAX] = {NULL};

        for (int j = 0; j < C; j++) {
            int key;
            scanf("%d", &key);
            insert(hashTable, key, M);
        }

        printHashTable(hashTable, M);
        if (i < N - 1) {
            printf("\n");
        }

        freeHashTable(hashTable, M);
    }

    return 0;
}
