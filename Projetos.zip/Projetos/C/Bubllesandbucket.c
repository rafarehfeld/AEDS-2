#include <stdio.h>
#include <stdlib.h>

int count_inversions(int arr[], int temp[], int left, int right);
int merge_and_count(int arr[], int temp[], int left, int mid, int right);

int main() {
    char line[1000000];  // Buffer for reading lines
    while (fgets(line, sizeof(line), stdin)) {
        int n, i;
        sscanf(line, "%d", &n);  // Read the first number which is the size
        if (n == 0) break;

        int *arr = (int *)malloc(n * sizeof(int));
        int *temp = (int *)malloc(n * sizeof(int));

        // Read the permutation
        char *token = strtok(line, " ");
        token = strtok(NULL, " ");
        for (i = 0; i < n; i++) {
            arr[i] = atoi(token);
            token = strtok(NULL, " ");
        }

        int inversions = count_inversions(arr, temp, 0, n - 1);

        // Determine the winner
        if (inversions % 2 == 0) {
            printf("Carlos\n");
        } else {
            printf("Marcelo\n");
        }

        free(arr);
        free(temp);
    }

    return 0;
}

int count_inversions(int arr[], int temp[], int left, int right) {
    int mid, inv_count = 0;
    if (right > left) {
        mid = (right + left) / 2;

        inv_count += count_inversions(arr, temp, left, mid);
        inv_count += count_inversions(arr, temp, mid + 1, right);

        inv_count += merge_and_count(arr, temp, left, mid + 1, right);
    }
    return inv_count;
}

int merge_and_count(int arr[], int temp[], int left, int mid, int right) {
    int i, j, k;
    int inv_count = 0;

    i = left;  // Starting index for left subarray
    j = mid;   // Starting index for right subarray
    k = left;  // Starting index to be sorted

    while ((i <= mid - 1) && (j <= right)) {
        if (arr[i] <= arr[j]) {
            temp[k++] = arr[i++];
        } else {
            temp[k++] = arr[j++];
            inv_count = inv_count + (mid - i);
        }
    }

    while (i <= mid - 1)
        temp[k++] = arr[i++];

    while (j <= right)
        temp[k++] = arr[j++];

    for (i = left; i <= right; i++)
        arr[i] = temp[i];

    return inv_count;
}
