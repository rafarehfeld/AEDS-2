#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 1000

typedef struct {
    char data[MAX_SIZE];
    int top;
} Stack;

void initStack(Stack *s) {
    s->top = -1;
}

void push(Stack *s, char item) {
    if (s->top == MAX_SIZE - 1) {
        printf("Stack Overflow\n");
        exit(EXIT_FAILURE);
    }
    s->data[++s->top] = item;
}

char pop(Stack *s) {
    if (s->top == -1) {
        printf("Stack Underflow\n");
        exit(EXIT_FAILURE);
    }
    return s->data[s->top--];
}

int isEmpty(Stack *s) {
    return s->top == -1;
}

char peek(Stack *s) {
    if (isEmpty(s)) {
        printf("Stack is empty\n");
        exit(EXIT_FAILURE);
    }
    return s->data[s->top];
}

char* checkParenthesisBalance(char *expression) {
    Stack stack;
    initStack(&stack);

    for (int i = 0; i < strlen(expression); i++) {
        char c = expression[i];
        if (c == '(') {
            push(&stack, c);
        } else if (c == ')') {
            if (isEmpty(&stack)) {
                return "incorrect";
            }
            char top = pop(&stack);
            if (top != '(') {
                return "incorrect";
            }
        }
    }

    if (isEmpty(&stack)) {
        return "correct";
    } else {
        return "incorrect";
    }
}

int main() {
    char expression[MAX_SIZE];

    while (fgets(expression, MAX_SIZE, stdin) != NULL) {
        expression[strcspn(expression, "\n")] = '\0'; // Remove newline character
        char *result = checkParenthesisBalance(expression);
        printf("%s\n", result);
    }

    return 0;
}