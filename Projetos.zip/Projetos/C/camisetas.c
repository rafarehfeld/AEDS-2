#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[61];
    char color[8];
    char size;
} Tshirt;

int compare(const void *a, const void *b) {
    Tshirt *tshirtA = (Tshirt *)a;
    Tshirt *tshirtB = (Tshirt *)b;

    int colorComparison = strcmp(tshirtA->color, tshirtB->color);
    if (colorComparison != 0) {
        return colorComparison;
    }

    if (tshirtA->size != tshirtB->size) {
        return tshirtB->size - tshirtA->size;
    }

    return strcmp(tshirtA->name, tshirtB->name);
}

int main() {
    int N;
    int first = 1;

    while (scanf("%d", &N) && N != 0) {
        Tshirt tshirts[N];

        for (int i = 0; i < N; i++) {
            scanf(" %[^\n]", tshirts[i].name);
            scanf("%s %c", tshirts[i].color, &tshirts[i].size);
        }

        qsort(tshirts, N, sizeof(Tshirt), compare);

        if (!first) {
            printf("\n");
        }
        first = 0;

        for (int i = 0; i < N; i++) {
            printf("%s %c %s\n", tshirts[i].color, tshirts[i].size, tshirts[i].name);
        }
    }

    return 0;
}
