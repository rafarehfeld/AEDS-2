#include <stdio.h>
#include <string.h>

struct Creature {
    char name[100];
    int powerLevel;
    int godsKilled;
    int timesDied;
};

int isBetterCandidate(struct Creature candidate, struct Creature currentGodofor) {
    if (candidate.powerLevel != currentGodofor.powerLevel) {
        return candidate.powerLevel > currentGodofor.powerLevel;
    }
    if (candidate.godsKilled != currentGodofor.godsKilled) {
        return candidate.godsKilled > currentGodofor.godsKilled;
    }
    if (candidate.timesDied != currentGodofor.timesDied) {
        return candidate.timesDied < currentGodofor.timesDied;
    }
    return strcmp(candidate.name, currentGodofor.name) < 0;
}

int main() {
    int N;
    scanf("%d", &N);
    struct Creature godofor;
    for (int i = 0; i < N; i++) {
        struct Creature candidate;
        scanf("%s %d %d %d", candidate.name, &candidate.powerLevel, &candidate.godsKilled, &candidate.timesDied);
        if (i == 0 || isBetterCandidate(candidate, godofor)) {
            godofor = candidate;
        }
    }
    printf("%s\n", godofor.name);
    return 0;
}