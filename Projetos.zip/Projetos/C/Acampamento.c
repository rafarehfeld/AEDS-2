#include <stdio.h>
#include <string.h>

#define MAX_CHILDREN 100
#define MAX_NAME_LENGTH 30

typedef struct {
    char name[MAX_NAME_LENGTH];
    int token;
} Child;

int main() {
    int N, i, j, index, steps, direction;
    Child children[MAX_CHILDREN];

    while (scanf("%d", &N) && N != 0) {
        for (i = 0; i < N; i++) {
            scanf("%s %d", children[i].name, &children[i].token);
        }

        index = 0;
        while (N > 1) {
            steps = children[index].token;
            if (steps % 2 == 0) {
                direction = 1;  // Horário
            } else {
                direction = -1; // Anti-horário
            }

            // Remove a criança do círculo
            for (j = index; j < N - 1; j++) {
                children[j] = children[j + 1];
            }
            N--;

            if (direction == 1) {
                index = (index + steps - 1) % N;
            } else {
                index = (index - steps) % N;
                if (index < 0) {
                    index += N;
                }
            }
        }

        printf("Vencedor(a): %s\n", children[0].name);
    }

    return 0;
}
