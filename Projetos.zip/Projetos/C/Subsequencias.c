#include <stdio.h>
#include <string.h>

int isSubsequence(char *s, char *r) {
    int i = 0, j = 0;
    int s_len = strlen(s), r_len = strlen(r);
    
    while (i < s_len && j < r_len) {
        if (s[i] == r[j]) {
            j++;
        }
        i++;
    }
    return j == r_len;
}

int main() {
    int n, q;
    char s[100000];
    char r[100];

    scanf("%d", &n);
    
    for (int i = 0; i < n; i++) {
        scanf("%s", s);
        scanf("%d", &q);
        
        for (int j = 0; j < q; j++) {
            scanf("%s", r);
            if (isSubsequence(s, r)) {
                printf("Yes\n");
            } else {
                printf("No\n");
            }
        }
    }
    
    return 0;
}
