#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
    char c;
    struct Node *next, *prev;
} Node;

Node *create_node(char c) {
    Node *node = (Node *)malloc(sizeof(Node));
    node->c = c;
    node->next = node->prev = NULL;
    return node;
}

void insert_after(Node *position, Node *new_node) {
    new_node->next = position->next;
    new_node->prev = position;
    if (position->next) {
        position->next->prev = new_node;
    }
    position->next = new_node;
}

void insert_before(Node *position, Node *new_node) {
    new_node->prev = position->prev;
    new_node->next = position;
    if (position->prev) {
        position->prev->next = new_node;
    }
    position->prev = new_node;
}

void print_and_free(Node *head) {
    Node *cur = head->next;
    while (cur) {
        printf("%c", cur->c);
        Node *tmp = cur;
        cur = cur->next;
        free(tmp);
    }
    printf("\n");
}

int main() {
    char line[100001];
    while (fgets(line, 100001, stdin) != NULL) {
        Node *head = create_node('\0');
        Node *tail = head;
        Node *cur = head;
        
        int i = 0;
        while (line[i] != '\0' && line[i] != '\n') {
            if (line[i] == '[') {
                cur = head;
            } else if (line[i] == ']') {
                cur = tail;
            } else {
                Node *new_node = create_node(line[i]);
                if (cur == tail) {
                    insert_after(tail, new_node);
                    tail = new_node;
                } else {
                    insert_after(cur, new_node);
                }
                cur = new_node;
            }
            i++;
        }
        print_and_free(head);
    }
    return 0;
}
