#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INPUT_SIZE 100

typedef struct {
    char *identificador;
    struct Aeronave *prox;
} Aeronave;

typedef struct {
    Aeronave *inicio;
    Aeronave *fim;
} Fila;

Fila* inicializarFila() {
    Fila *fila = (Fila*)malloc(sizeof(Fila));
    fila->inicio = NULL;
    fila->fim = NULL;
    return fila;
}

void enfileirar(Fila *fila, char *identificador) {
    Aeronave *novaAeronave = (Aeronave*)malloc(sizeof(Aeronave));
    novaAeronave->identificador = strdup(identificador);
    novaAeronave->prox = NULL;

    if (fila->inicio == NULL) {
        fila->inicio = novaAeronave;
    } else {
        fila->fim->prox = novaAeronave;
    }
    fila->fim = novaAeronave;
}

char* desenfileirar(Fila *fila) {
    if (fila->inicio == NULL) {
        return NULL;
    }
    Aeronave *aeronave = fila->inicio;
    fila->inicio = fila->inicio->prox;
    if (fila->inicio == NULL) {
        fila->fim = NULL;
    }
    char *identificador = aeronave->identificador;
    free(aeronave);
    return identificador;
}

int main() {
    Fila *leste = inicializarFila();
    Fila *norte = inicializarFila();
    Fila *sul = inicializarFila();
    Fila *oeste = inicializarFila();

    int ponto = 0;
    char *aeronaves[MAX_INPUT_SIZE];
    int num_aeronaves = 0;

    while (1) {
        char entrada[MAX_INPUT_SIZE];
        fgets(entrada, MAX_INPUT_SIZE, stdin);
        if (entrada[0] == '0') {
            break;
        } else if (entrada[0] == '-') {
            ponto = atoi(entrada);
        } else {
            switch (ponto) {
                case -1:
                    enfileirar(oeste, entrada);
                    break;
                case -2:
                    enfileirar(sul, entrada);
                    break;
                case -3:
                    enfileirar(norte, entrada);
                    break;
                case -4:
                    enfileirar(leste, entrada);
                    break;
            }
        }
    }

    while (1) {
        char *aeronave;

        aeronave = desenfileirar(oeste);
        if (aeronave != NULL) {
            aeronaves[num_aeronaves++] = aeronave;
        }

        aeronave = desenfileirar(norte);
        if (aeronave != NULL) {
            aeronaves[num_aeronaves++] = aeronave;
        }

        aeronave = desenfileirar(sul);
        if (aeronave != NULL) {
            aeronaves[num_aeronaves++] = aeronave;
        }

        aeronave = desenfileirar(leste);
        if (aeronave != NULL) {
            aeronaves[num_aeronaves++] = aeronave;
        }

        if (oeste->inicio == NULL && norte->inicio == NULL && sul->inicio == NULL && leste->inicio == NULL) {
            break;
        }
    }

    for (int i = 0; i < num_aeronaves; i++) {
        printf("%s ", aeronaves[i]);
        free(aeronaves[i]);
    }

    return 0;
}
