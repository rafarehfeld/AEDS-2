#include <stdio.h>

int main() {
    int N;
    while (1) {
        scanf("%d", &N);
        if (N == 0) break;

        long lonelyNumber = 0;
        long number;

        for (int i = 0; i < N; i++) {
            scanf("%ld", &number);
            lonelyNumber ^= number; // Using XOR to find the lonely number
        }

        printf("%ld\n", lonelyNumber);
    }

    return 0;
}