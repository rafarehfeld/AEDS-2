#include <stdio.h>
#include <string.h>

#define MAX_SERVERS 200
#define MAX_CLIENTS 200
#define MAX_APPS 100
#define MAX_APP_NAME 21

typedef struct {
    int count;
    char apps[MAX_APPS][MAX_APP_NAME];
} Server;

typedef struct {
    int count;
    char apps[MAX_APPS][MAX_APP_NAME];
} Client;

Server servers[MAX_SERVERS];
Client clients[MAX_CLIENTS];

int main() {
    int N, M;

    while (scanf("%d %d", &N, &M) && (N || M)) {
        // Read servers' data
        for (int i = 0; i < N; i++) {
            scanf("%d", &servers[i].count);
            for (int j = 0; j < servers[i].count; j++) {
                scanf("%s", servers[i].apps[j]);
            }
        }

        // Read clients' data
        for (int i = 0; i < M; i++) {
            scanf("%d", &clients[i].count);
            for (int j = 0; j < clients[i].count; j++) {
                scanf("%s", clients[i].apps[j]);
            }
        }

        int totalConnections = 0;

        // Calculate connections
        for (int i = 0; i < M; i++) {
            int clientConnections[MAX_SERVERS] = {0};
            for (int j = 0; j < clients[i].count; j++) {
                for (int k = 0; k < N; k++) {
                    for (int l = 0; l < servers[k].count; l++) {
                        if (strcmp(clients[i].apps[j], servers[k].apps[l]) == 0) {
                            clientConnections[k] = 1;
                            break;
                        }
                    }
                }
            }
            for (int k = 0; k < N; k++) {
                totalConnections += clientConnections[k];
            }
        }

        printf("%d\n", totalConnections);
    }

    return 0;
}
