#include <stdio.h>

int bubbleSortAndCountSwaps(int arr[], int n) {
    int swapCount = 0;
    int temp;
    int swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = 0;
        for (int j = 0; j < n - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                // Swap arr[j] and arr[j + 1]
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapCount++;
                swapped = 1;
            }
        }
        // If no two elements were swapped in the inner loop, then the array is sorted
        if (!swapped) {
            break;
        }
    }
    return swapCount;
}

int main() {
    int N;
    scanf("%d", &N); // Number of test cases

    for (int i = 0; i < N; i++) {
        int L;
        scanf("%d", &L); // Length of the train
        int train[L];
        for (int j = 0; j < L; j++) {
            scanf("%d", &train[j]);
        }
        int swaps = bubbleSortAndCountSwaps(train, L);
        printf("Optimal train swapping takes %d swaps.\n", swaps);
    }

    return 0;
}