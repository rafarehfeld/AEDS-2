#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char nome[100];
    int ouro;
    int prata;
    int bronze;
} Paises;

int verificapais(char nome[], Paises* vet[], int tam) {
    for (int i = 0; i < tam; i++) {
        if (strcmp(nome, vet[i]->nome) == 0) {
            return i;
        }
    }
    Paises* novo = (Paises*)malloc(sizeof(Paises));
    strcpy(novo->nome, nome);
    novo->ouro = 0;
    novo->prata = 0;
    novo->bronze = 0;
    vet[tam] = novo;
    return tam;
}

int comparador(const void* a, const void* b) {
    Paises* pa = *(Paises**)a;
    Paises* pb = *(Paises**)b;

    if (pa->ouro != pb->ouro) return pb->ouro - pa->ouro;
    if (pa->prata != pb->prata) return pb->prata - pa->prata;
    if (pa->bronze != pb->bronze) return pb->bronze - pa->bronze;

    return strcmp(pa->nome, pb->nome);
}

int main() {
    char desc[100];
    Paises* vet[25] = { NULL };
    int tam = 0;

    while (scanf("%[^\n]%*c", desc) != EOF) {  // Leia a descrição e consuma o newline
        char ouro[50], prata[50], bronze[50];
        scanf("%[^\n]%*c", ouro);               // Leia o país do ouro e consuma o newline
        scanf("%[^\n]%*c", prata);              // Leia o país da prata e consuma o newline
        scanf("%[^\n]%*c", bronze);             // Leia o país do bronze e consuma o newline
        
        int a = verificapais(ouro, vet, tam);
        if (a == tam) tam++;
        vet[a]->ouro++;

        int b = verificapais(prata, vet, tam);
        if (b == tam) tam++;
        vet[b]->prata++;

        int c = verificapais(bronze, vet, tam);
        if (c == tam) tam++;
        vet[c]->bronze++;
    }

    qsort(vet, tam, sizeof(Paises*), comparador);

    printf("Quadro de medalhas\n");
    for (int i = 0; i < tam; i++) {
        printf("%s %d %d %d\n", vet[i]->nome, vet[i]->ouro, vet[i]->prata, vet[i]->bronze);
    }

    // Liberar memória alocada
    for (int i = 0; i < tam; i++) {
        free(vet[i]);
    }

    return 0;
}

