#include <stdio.h>

typedef struct {
    int hora;
    int minuto;
    int critico;
} Paciente;

typedef struct {
    int hora;
    int minuto;
} Atendimento;

void Att(Atendimento *medico, int h, int m) {
    if (m <= 30) {
        medico->minuto = 30;
    } else {
        medico->hora++;
        medico->minuto = 0;
    }
}

void AttMax(Atendimento *medico, int h, int m) {
    if (medico->minuto < 30) {
        medico->minuto = 30;
    } else {
        medico->hora++;
        medico->minuto = 0;
    }
}

int main() {
    int x;

    while (scanf("%d", &x) != EOF) {
        int naoatendido = 0;
        Paciente vet[x];

        for (int i = 0; i < x; i++) {
            int h, m, c;
            scanf("%d %d %d", &h, &m, &c);
            vet[i].hora = h;
            vet[i].minuto = m;
            vet[i].critico = c;
        }

        Atendimento medico = { vet[0].hora, vet[0].minuto };

        for (int i = 0; i < x; i++) {
            if (i == 0) {
                Att(&medico, vet[i].hora, vet[i].minuto);
            } else if (medico.hora < vet[i].hora) {
                Att(&medico, vet[i].hora, vet[i].minuto);
            } else {
                if (medico.hora == vet[i].hora) {
                    AttMax(&medico, vet[i].hora, vet[i].minuto);
                } else {
                    vet[i].minuto += vet[i].critico;
                    if (vet[i].minuto >= 60) {
                        vet[i].minuto -= 60;
                        vet[i].hora++;
                    }
                    if (medico.hora == vet[i].critico && medico.minuto <= vet[i].critico) {
                        AttMax(&medico, vet[i].hora, vet[i].minuto);
                    } else {
                        naoatendido++;
                    }
                }
            }
        }
        printf("%d\n", naoatendido);
    }

    return 0;
}
