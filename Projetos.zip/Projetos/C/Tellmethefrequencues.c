#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1000

typedef struct {
    int ascii;
    int frequency;
} CharFrequency;

int compare(const void *a, const void *b) {
    CharFrequency *cf1 = (CharFrequency *)a;
    CharFrequency *cf2 = (CharFrequency *)b;
    
    if (cf1->frequency == cf2->frequency) {
        return cf2->ascii - cf1->ascii; // Higher ASCII value first if same frequency
    } else {
        return cf1->frequency - cf2->frequency; // Ascending order of frequency
    }
}

void processLine(char *line) {
    int frequencies[128] = {0}; // ASCII characters range from 0 to 127
    int len = strlen(line);

    // Calculate frequencies
    for (int i = 0; i < len; i++) {
        int ascii = (int)line[i];
        frequencies[ascii]++;
    }

    // Count unique characters
    int uniqueCount = 0;
    for (int i = 0; i < 128; i++) {
        if (frequencies[i] > 0) {
            uniqueCount++;
        }
    }

    // Create an array of CharFrequency to store characters and their frequencies
    CharFrequency *charFreqs = (CharFrequency *)malloc(uniqueCount * sizeof(CharFrequency));
    int index = 0;
    for (int i = 0; i < 128; i++) {
        if (frequencies[i] > 0) {
            charFreqs[index].ascii = i;
            charFreqs[index].frequency = frequencies[i];
            index++;
        }
    }

    // Sort the array based on the frequency and ASCII value
    qsort(charFreqs, uniqueCount, sizeof(CharFrequency), compare);

    // Print the sorted frequencies
    for (int i = 0; i < uniqueCount; i++) {
        printf("%d %d\n", charFreqs[i].ascii, charFreqs[i].frequency);
    }

    // Free the allocated memory
    free(charFreqs);
}

int main() {
    char line[MAX_LINE_LENGTH];
    int firstOutput = 1;

    while (fgets(line, sizeof(line), stdin)) {
        // Remove the newline character if present
        line[strcspn(line, "\r\n")] = '\0';
        
        if (!firstOutput) {
            printf("\n"); // Print a blank line between different inputs
        }
        firstOutput = 0;

        processLine(line);
    }

    return 0;
}
