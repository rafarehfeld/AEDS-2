#include <stdio.h>
#include <string.h>

void compress(char *input, char *output) {
    int length = strlen(input);
    int count;
    int outIndex = 0;

    for (int i = 0; i < length; i++) {
        char currentChar = input[i];

        if (currentChar == ' ') {
            count = 0;
            while (i < length && input[i] == ' ') {
                count++;
                i++;
            }
            i--; // Adjust for the extra increment in the inner loop

            if (count > 2) {
                while (count > 255) {
                    output[outIndex++] = '$';
                    output[outIndex++] = 255;
                    count -= 255;
                }
                output[outIndex++] = '$';
                output[outIndex++] = count;
            } else {
                for (int j = 0; j < count; j++) {
                    output[outIndex++] = ' ';
                }
            }
        } else if (currentChar == '0') {
            count = 0;
            while (i < length && input[i] == '0') {
                count++;
                i++;
            }
            i--; // Adjust for the extra increment in the inner loop

            if (count > 2) {
                while (count > 255) {
                    output[outIndex++] = '#';
                    output[outIndex++] = 255;
                    count -= 255;
                }
                output[outIndex++] = '#';
                output[outIndex++] = count;
            } else {
                for (int j = 0; j < count; j++) {
                    output[outIndex++] = '0';
                }
            }
        } else {
            output[outIndex++] = currentChar;
        }
    }

    output[outIndex] = '\0';
}

int main() {
    int N;
    scanf("%d", &N);
    getchar(); // Consume the newline character after the number of test cases

    for (int i = 0; i < N; i++) {
        char input[2001];
        char output[2001];
        fgets(input, sizeof(input), stdin);
        // Remove the newline character if present
        input[strcspn(input, "\n")] = '\0';

        compress(input, output);
        printf("%s\n", output);
    }

    return 0;
}
