#include <stdio.h>
#include <stdlib.h>

#define MAX_CARDS 50

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct {
    Node *front;
    Node *rear;
} Queue;

Queue* createQueue() {
    Queue *q = (Queue*)malloc(sizeof(Queue));
    q->front = NULL;
    q->rear = NULL;
    return q;
}

void enqueue(Queue *q, int data) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->next = NULL;
    if (q->rear == NULL) {
        q->front = newNode;
        q->rear = newNode;
    } else {
        q->rear->next = newNode;
        q->rear = newNode;
    }
}

int dequeue(Queue *q) {
    if (q->front == NULL) {
        printf("Queue is empty\n");
        exit(EXIT_FAILURE);
    }
    int data = q->front->data;
    Node *temp = q->front;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return data;
}

void simulateCardGame(int n) {
    Queue *deck = createQueue();
    Queue *discarded = createQueue();

    // Initialize the deck from 1 to n
    for (int i = 1; i <= n; i++) {
        enqueue(deck, i);
    }

    while (deck->front != NULL && deck->front->next != NULL) {
        // Step 1: Discard the top card
        int discardedCard = dequeue(deck);
        enqueue(discarded, discardedCard);

        // Step 2: Move the new top card to the bottom
        int newTopCard = dequeue(deck);
        enqueue(deck, newTopCard);
    }

    // Last remaining card
    int remainingCard = dequeue(deck);

    // Output
    printf("Discarded cards: ");
    while (discarded->front != NULL) {
        printf("%d", dequeue(discarded));
        if (discarded->front != NULL) {
            printf(", ");
        }
    }
    printf("\nRemaining card: %d\n", remainingCard);

    free(deck);
    free(discarded);
}

int main() {
    int n;
    while (1) {
        scanf("%d", &n);
        if (n == 0) break;

        simulateCardGame(n);
    }

    return 0;
}