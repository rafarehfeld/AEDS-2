#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void swap(int *arr, int i, int j) {
    int temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}

int main() {
    int N;
    while (scanf("%d", &N) && N != 0) {
        int target[N];
        int current[N];
        for (int i = 0; i < N; i++) {
            scanf("%d", &target[i]);
            target[i]--; // Convert to 0-based index
            current[i] = i; // Initial positions
        }

        int strokes[4 * N * N];
        int strokeCount = 0;

        bool possible = true;
        for (int k = 0; k < 4 * N * N && possible; k++) {
            possible = false;
            for (int i = 0; i < N - 1; i++) {
                if (current[i] != target[i] && current[i + 1] != target[i + 1]) {
                    strokes[strokeCount++] = i + 1;
                    swap(current, i, i + 1);
                    possible = true;
                }
            }

            bool equal = true;
            for (int i = 0; i < N; i++) {
                if (current[i] != target[i]) {
                    equal = false;
                    break;
                }
            }
            if (equal) {
                possible = true;
                break;
            }
        }

        bool equal = true;
        for (int i = 0; i < N; i++) {
            if (current[i] != target[i]) {
                equal = false;
                break;
            }
        }

        if (equal) {
            printf("%d", strokeCount);
            for (int i = 0; i < strokeCount; i++) {
                printf(" %d", strokes[i]);
            }
            printf("\n");
        } else {
            printf("No solution\n");
        }
    }

    return 0;
}
