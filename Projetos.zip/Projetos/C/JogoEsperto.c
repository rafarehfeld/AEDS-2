#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 10001

typedef struct {
    int value;
    int steps;
} Node;

typedef struct {
    Node* nodes;
    int front;
    int rear;
    int size;
} Queue;

Queue* createQueue(int capacity) {
    Queue* queue = (Queue*) malloc(sizeof(Queue));
    queue->nodes = (Node*) malloc(capacity * sizeof(Node));
    queue->front = 0;
    queue->rear = -1;
    queue->size = 0;
    return queue;
}

bool isQueueEmpty(Queue* queue) {
    return queue->size == 0;
}

void enqueue(Queue* queue, int value, int steps) {
    queue->rear = (queue->rear + 1) % MAX;
    queue->nodes[queue->rear].value = value;
    queue->nodes[queue->rear].steps = steps;
    queue->size++;
}

Node dequeue(Queue* queue) {
    Node node = queue->nodes[queue->front];
    queue->front = (queue->front + 1) % MAX;
    queue->size--;
    return node;
}

void freeQueue(Queue* queue) {
    free(queue->nodes);
    free(queue);
}

int minOperations(int N, int M) {
    if (N == M) {
        return 0;
    }

    bool visited[MAX] = {false};
    Queue* queue = createQueue(MAX);
    
    enqueue(queue, N, 0);
    visited[N] = true;

    while (!isQueueEmpty(queue)) {
        Node current = dequeue(queue);
        int value = current.value;
        int steps = current.steps;

        int nextValues[] = {
            value * 2,
            value * 3,
            value % 2 == 0 ? value / 2 : value,
            value % 3 == 0 ? value / 3 : value,
            value + 7,
            value - 7
        };

        for (int i = 0; i < 6; i++) {
            int nextValue = nextValues[i];
            if (nextValue == M) {
                freeQueue(queue);
                return steps + 1;
            }
            if (nextValue >= 0 && nextValue < MAX && !visited[nextValue]) {
                visited[nextValue] = true;
                enqueue(queue, nextValue, steps + 1);
            }
        }
    }

    freeQueue(queue);
    return -1;
}

int main() {
    // Exemplos de teste
    printf("%d\n", minOperations(10, 15)); // Saída esperada: 2
    printf("%d\n", minOperations(45, 15)); // Saída esperada: 1
    printf("%d\n", minOperations(84, 63)); // Saída esperada: 3
    return 0;
}
